"""
Configuração central — tudo vem do AMBIENTE, nada de segredos no código.

Ao contrário da versão antiga (que trazia PHONE_NUMBER_ID, PROVIDER_WHATSAPP e
VERIFY_TOKEN="teste123" embutidos no ficheiro), aqui não há defaults sensíveis.
Uma variável em falta fica a None e as rotas que dela dependem falham de forma
controlada (ver `bot.configuracao_em_falta`).

Ver `.env.example` para a lista completa.
"""

from __future__ import annotations

import os


def _limpo(nome: str):
    valor = os.environ.get(nome)
    if valor is None:
        return None
    valor = valor.strip()
    return valor or None


# --- Identidade do negócio -------------------------------------------------
BUSINESS_NAME = _limpo("BUSINESS_NAME") or "Daniela Beauty"
BUSINESS_ADDRESS = _limpo("BUSINESS_ADDRESS") or ""

# --- WhatsApp Cloud API (Meta) — SEM defaults -----------------------------
WHATSAPP_TOKEN = _limpo("WHATSAPP_TOKEN")
PHONE_NUMBER_ID = _limpo("PHONE_NUMBER_ID")
VERIFY_TOKEN = _limpo("VERIFY_TOKEN")
PROVIDER_WHATSAPP = _limpo("PROVIDER_WHATSAPP")
# App Secret da app Meta — usado para validar a assinatura X-Hub-Signature-256
# dos webhooks. Sem ele, a validação de assinatura fica em modo "aviso" (ver
# bot.verificar_assinatura) — aceitável em desenvolvimento, NÃO em produção.
APP_SECRET = _limpo("APP_SECRET")

GRAPH_API_VERSION = _limpo("GRAPH_API_VERSION") or "v21.0"

# Nomes (não o conteúdo) dos templates Meta aprovados para o reminder 24h —
# ver notifications/reminders.py. Sem isto configurado, o reminder NUNCA
# finge um envio: fica "failed" e visível no Attention Center (ver §16 do
# patch P1) até o template ser aprovado e o nome configurado aqui.
WHATSAPP_REMINDER_TEMPLATE_PT = _limpo("WHATSAPP_REMINDER_TEMPLATE_PT")
WHATSAPP_REMINDER_TEMPLATE_DE = _limpo("WHATSAPP_REMINDER_TEMPLATE_DE")
WHATSAPP_REMINDER_TEMPLATE_EN = _limpo("WHATSAPP_REMINDER_TEMPLATE_EN")

# Idem, para o rebooking followup automático (P2, ver notifications/followup.py)
# — mesma regra: sem o nome do template aqui, o job nunca finge um envio.
WHATSAPP_REBOOKING_TEMPLATE_PT = _limpo("WHATSAPP_REBOOKING_TEMPLATE_PT")
WHATSAPP_REBOOKING_TEMPLATE_DE = _limpo("WHATSAPP_REBOOKING_TEMPLATE_DE")
WHATSAPP_REBOOKING_TEMPLATE_EN = _limpo("WHATSAPP_REBOOKING_TEMPLATE_EN")

# Idem, para a proposta de reagendamento iniciada pelo painel FORA da janela
# de 24h (P4.1, ver notifications/reschedule.py). Dentro da janela usa-se
# sempre uma mensagem interativa normal (enviar_botoes) — o template só é
# necessário quando o cliente não escreveu nas últimas 24h.
WHATSAPP_RESCHEDULE_TEMPLATE_PT = _limpo("WHATSAPP_RESCHEDULE_TEMPLATE_PT")
WHATSAPP_RESCHEDULE_TEMPLATE_DE = _limpo("WHATSAPP_RESCHEDULE_TEMPLATE_DE")
WHATSAPP_RESCHEDULE_TEMPLATE_EN = _limpo("WHATSAPP_RESCHEDULE_TEMPLATE_EN")

# Idem, para a campanha "Reativação de clientes" (P5, ver campaigns/engine.py)
# — a ÚNICA campanha lógica desta primeira versão. Sem o nome do template
# aqui, o envio nunca finge sucesso: cada destinatário fica "failed" (ver
# campaigns.engine.executar_envio_campanha) até o template ser aprovado e
# configurado — a mesma regra do reminder 24h e do rebooking automático.
WHATSAPP_CAMPAIGN_TEMPLATE_PT = _limpo("WHATSAPP_CAMPAIGN_TEMPLATE_PT")
WHATSAPP_CAMPAIGN_TEMPLATE_DE = _limpo("WHATSAPP_CAMPAIGN_TEMPLATE_DE")
WHATSAPP_CAMPAIGN_TEMPLATE_EN = _limpo("WHATSAPP_CAMPAIGN_TEMPLATE_EN")

# Quantos destinatários (no máximo) um ÚNICO ciclo do executor
# (notifications/jobs.py:process_due_jobs, chamado por /api/automacoes/correr)
# processa por campanha antes de reagendar o resto para um novo lote — nunca
# um disparo de centenas em simultâneo (ver campaigns/engine.py, throttling).
CAMPAIGN_SEND_BATCH_SIZE = int(_limpo("CAMPAIGN_SEND_BATCH_SIZE") or "40")

# --- Painel / dashboard (HTTP Basic) — SEM defaults ----------------------
DASHBOARD_USER = _limpo("DASHBOARD_USER")
DASHBOARD_PASSWORD = _limpo("DASHBOARD_PASSWORD")

# --- Infra ---------------------------------------------------------------
# Produção: Postgres via DATABASE_URL. Desenvolvimento/local: SQLite.
DATABASE_URL = _limpo("DATABASE_URL")
SQLITE_PATH = _limpo("SESSOES_DB") or "sessoes.db"
MEDIA_DIR = _limpo("MEDIA_DIR") or "media_pedidos"
PUBLIC_BASE_URL = (_limpo("PUBLIC_BASE_URL") or "").rstrip("/")

# Reter o horário assim que é escolhido, enquanto o cliente confirma.
RESERVA_TEMPORARIA_MINUTOS = int(_limpo("RESERVA_TEMPORARIA_MINUTOS") or "15")

# --- Comportamento do fluxo de marcação ---------------------------------
# False (por agora): marcações do bot entram já como "confirmed".
# Ligar mais tarde não exige refactor: `bot.estado_inicial_marcacao()` já
# devolve "pending" quando isto for True.
BOOKING_REQUIRES_APPROVAL = (_limpo("BOOKING_REQUIRES_APPROVAL") or "false").lower() in (
    "1", "true", "yes", "sim", "on",
)

# --- Seed DEMO temporário (/api/dev/seed-dashboard) — DESLIGADO por omissão.
# Só existe para encher o dashboard V3 no Render Free (sem Shell). Nunca
# ligar num ambiente com clientes reais. Ver bot.py — secção "seed DEMO".
ENABLE_DEMO_SEED = (_limpo("ENABLE_DEMO_SEED") or "false").lower() in (
    "1", "true", "yes", "sim", "on",
)

# Estimativa de minutos poupados por CADA ação automatizada real (reminder
# enviado, follow-up de rebooking, agradecimento pós-atendimento, PDF de
# fatura enviado, etc.) — ver reports/results.py "Tempo poupado". É sempre
# rotulado como estimativa na UI, nunca como "tempo real poupado".
ESTIMATED_MINUTES_SAVED_PER_AUTOMATION = int(
    _limpo("ESTIMATED_MINUTES_SAVED_PER_AUTOMATION") or "3"
)

# Prefixo dos números de telefone DEMO (seed do dashboard). Usado em dois
# sítios: aqui para identificar clientes demo em geral, e em
# `messaging/whatsapp.py:enviar()` para bloquear qualquer envio real à Meta
# para esse prefixo — nunca deve enviar-se uma mensagem WhatsApp real a um
# cliente demo, mesmo por engano.
DEMO_PHONE_PREFIX = "4179998"

# Meses que o TEXTO das conversas com clientes fica guardado (ver
# messaging/conversas.py e migração 25). Isto é conteúdo de conversas de
# pessoas reais numa base de dados na Suíça: guardar para sempre por
# omissão não é defensável, e a limpeza é trivial agora e horrível daqui a
# um ano com 50 mil linhas lá dentro. Configurável por ambiente porque o
# prazo é uma decisão do negócio, não do código. 0 desliga a limpeza.
CONVERSAS_RETENCAO_MESES = int(_limpo("CONVERSAS_RETENCAO_MESES") or "12")


def graph_url() -> str | None:
    if not PHONE_NUMBER_ID:
        return None
    return f"https://graph.facebook.com/{GRAPH_API_VERSION}/{PHONE_NUMBER_ID}/messages"


def usa_postgres() -> bool:
    return bool(DATABASE_URL and DATABASE_URL.startswith(("postgres://", "postgresql://")))


def em_falta_para_whatsapp() -> list[str]:
    """Nomes das variáveis obrigatórias para o bot WhatsApp funcionar."""
    faltam = []
    for nome, valor in (
        ("WHATSAPP_TOKEN", WHATSAPP_TOKEN),
        ("PHONE_NUMBER_ID", PHONE_NUMBER_ID),
        ("VERIFY_TOKEN", VERIFY_TOKEN),
        ("PROVIDER_WHATSAPP", PROVIDER_WHATSAPP),
    ):
        if not valor:
            faltam.append(nome)
    return faltam


def em_falta_para_painel() -> list[str]:
    return [n for n, v in (("DASHBOARD_USER", DASHBOARD_USER),
                           ("DASHBOARD_PASSWORD", DASHBOARD_PASSWORD)) if not v]
