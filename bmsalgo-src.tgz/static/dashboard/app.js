/* =====================================================================
   Daniela Beauty — dashboard client
   Router por hash + views que consomem as APIs JSON de bot.py.
   Sem framework, sem build. ES2020.
   ===================================================================== */
"use strict";

/* ---------- core helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function h(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "html") e.innerHTML = v;
    else if (k === "dataset") Object.assign(e.dataset, v);
    else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    e.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return e;
}

function icon(name, cls = "") {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.7");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("class", ("ico " + (cls || "")).trim());
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS(ns, "use");
  use.setAttribute("href", "#i-" + name);
  svg.append(use);
  return svg;
}

async function api(url, opts) {
  const r = await fetch(url, opts);
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("json") ? await r.json().catch(() => ({})) : {};
  if (!r.ok) {
    const err = new Error(body.erro || `Erro ${r.status}`);
    err.status = r.status;
    err.body = body;
    throw err;
  }
  return body;
}
const jpost = (url, data) =>
  api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
const jput = (url, data) =>
  api(url, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
const jpatch = (url, data) =>
  api(url, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data || {}) });
const jdel = (url) => api(url, { method: "DELETE" });

function toast(msg, kind = "") {
  const t = h("div", { class: "toast " + (kind === "err" ? "err" : "") }, msg);
  $("#toasts").append(t);
  setTimeout(() => t.remove(), 3600);
}

/* ---------- formatters ---------- */
const chf = (cents) =>
  cents == null ? "—" : "CHF " + (cents / 100).toFixed(2).replace(".", ",");
/* ---- relógio do NEGÓCIO (Europe/Zurich), nunca o do browser ------------
   O servidor trabalha sempre em Europe/Zurich (TZ no render.yaml) e a
   agenda que chega da API está nessa hora. A linha "Agora" usava
   `new Date().getHours()` — o relógio de QUEM está a olhar. Basta um
   telemóvel em roaming, ou o portátil com o fuso errado, para a linha
   aparecer uma hora ao lado das marcações. Intl faz a conversão sem
   dependência nenhuma. */
const TZ_NEGOCIO = "Europe/Zurich";
const _horaNegocio = new Intl.DateTimeFormat("pt-PT", {
  timeZone: TZ_NEGOCIO, hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
const _dataNegocio = new Intl.DateTimeFormat("en-CA", {
  timeZone: TZ_NEGOCIO, year: "numeric", month: "2-digit", day: "2-digit" });
function horaAgora() { return _horaNegocio.format(new Date()); }           // "14:05"
function minutosAgora() { const [hh, mm] = horaAgora().split(":"); return (+hh) * 60 + (+mm); }
function hojeYmdNegocio() { return _dataNegocio.format(new Date()); }      // "2026-09-17"

function fmtMin(m) {
  m = Math.round(m || 0);
  if (m < 60) return m + " min";
  const hh = Math.floor(m / 60), r = m % 60;
  return r ? `${hh}h${String(r).padStart(2, "0")}` : `${hh}h`;
}
function fmtDataPt(iso) {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("pt-PT", { day: "2-digit", month: "short" });
}
const initials = (name) =>
  (name || "?").split(/\s+/).slice(0, 2).map((s) => s[0] || "").join("").toUpperCase();

const OP_LABEL = { scheduled: "Agendada", arrived: "Chegou", in_progress: "Em curso", done: "Concluída" };
const EST_LABEL = { confirmed: "Confirmada", pending: "Pendente", cancelled: "Cancelada", completed: "Concluída", no_show: "Não compareceu" };
// Reminder 24h (P1, ver notifications/reminders.py) — mesmos 5 conceitos do
// backend, sem inventar mais nenhum aqui.
const REMINDER_LABEL = { agendado: "Agendado", enviado: "Enviado", confirmado: "Confirmado",
                         nao_aplicavel: "Não aplicável", cancelado: "Cancelado", falhou: "Falhou" };
// Rebooking followup (P2, ver notifications/followup.py) — mesmos conceitos
// do backend (estado_rebooking_para_ui), sem inventar mais nenhum aqui.
const REBOOKING_LABEL = { agendado: "Agendado", enviado: "Enviado", mais_tarde: "Mais tarde",
                          cancelado_marcacao_existente: "Cancelado — já tem marcação",
                          cancelado: "Cancelado", falhou: "Falhou" };
function statusBadge(estado, op, bloqueiaHorario) {
  const e = (estado || "").toLowerCase();
  // Cores dedicadas por estado (ver .badge--* + --st-* em app.css) — nunca
  // reaproveitadas entre estados, para dar para reconhecer de relance
  // (mesma paleta da legenda .ag-legend e dos cartões .ag-ev.st-*).
  if (e === "cancelled")
    return h("span", { class: "badge badge--cancelled" }, bloqueiaHorario ? "Cancelada · horário bloqueado" : "Cancelada");
  if (e === "no_show") return h("span", { class: "badge badge--noshow" }, EST_LABEL.no_show);
  if (op === "done" || e === "completed") return h("span", { class: "badge badge--success" }, "Concluída");
  if (op === "in_progress") return h("span", { class: "badge badge--progress" }, "Em curso");
  if (op === "arrived") return h("span", { class: "badge badge--arrived" }, "Chegou");
  if (e === "pending") return h("span", { class: "badge badge--pending" }, EST_LABEL.pending);
  return h("span", { class: "badge badge--confirmed" }, EST_LABEL[e] || "Agendada");
}

function skeletonCard() { return h("div", { class: "card card--pad" }, h("div", { class: "skel", style: "height:64px" })); }
function emptyState(txt) {
  return h("div", { class: "empty" }, icon("today"), h("div", {}, txt));
}

/* ---------- drawer ---------- */
const Drawer = {
  el: null, scrim: null,
  init() {
    this.el = $("#drawer"); this.scrim = $("#scrim");
    this.scrim.addEventListener("click", () => this.close());
    // ESC nunca fecha o drawer por baixo de uma Modal aberta (P4.1
    // reagendamento): o teclado só chega à camada de cima.
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !Modal.isOpen()) this.close(); });
  },
  open(node) {
    if (!this.el.classList.contains("open")) this._returnFocus = document.activeElement;
    this.el.innerHTML = "";
    this.el.append(node);
    this.el.classList.add("open");
    this.scrim.classList.add("open");
    this.el.setAttribute("aria-hidden", "false");
    this.el.setAttribute("role", "dialog");
    this.el.setAttribute("aria-modal", "true");
    this.el.setAttribute("tabindex", "-1");
    const first = this.el.querySelector("button, a, input, select, [tabindex]");
    (first || this.el).focus();
  },
  close() {
    if (!this.el.classList.contains("open")) return;
    this.el.classList.remove("open");
    this.scrim.classList.remove("open");
    this.el.setAttribute("aria-hidden", "true");
    if (this._returnFocus && this._returnFocus.focus) this._returnFocus.focus();
    this._returnFocus = null;
  },
};

/* ---------- modal (dialog centrado — substitui window.confirm()/alert()) ----------
   Genérico: hoje só usado pela confirmação de reagendamento (P4.1, ver
   confirmarReagendamento() mais abaixo), mas não sabe nada sobre isso —
   qualquer novo diálogo custom no dashboard deve passar por aqui em vez de
   reintroduzir confirm()/alert() nativos. Root próprio (#modal-root),
   nunca o #scrim/#drawer: fica por cima de um Drawer aberto sem o afetar. */
const Modal = {
  root: null, panel: null, _closable: true, _onClose: null, _returnFocus: null,
  init() {
    this.root = $("#modal-root");
    this.root.addEventListener("click", (e) => { if (e.target === this.root && this._closable) this.close(); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && this.isOpen() && this._closable) { this.close(); return; }
      if (e.key === "Tab" && this.isOpen()) this._trapFocus(e);
    });
  },
  isOpen() { return !!this.root && this.root.classList.contains("open"); },
  // onClose é chamado sempre que a modal fecha, seja como for (X, ESC,
  // backdrop ou Modal.close() direto) — é o único sítio a que um chamador
  // precisa de ligar para saber "a modal fechou-se sem eu ter agido".
  open(node, { labelledby, closable = true, onClose } = {}) {
    this._closable = closable;
    this._onClose = onClose || null;
    this._returnFocus = document.activeElement;
    this.root.innerHTML = "";
    this.panel = node;
    node.setAttribute("role", "dialog");
    node.setAttribute("aria-modal", "true");
    node.setAttribute("tabindex", "-1");
    if (labelledby) node.setAttribute("aria-labelledby", labelledby);
    this.root.append(node);
    this.root.classList.add("open");
    this.root.setAttribute("aria-hidden", "false");
    const first = node.querySelector("button, a, input, select, [tabindex]");
    (first || node).focus();
  },
  setClosable(v) { this._closable = v; },
  close() {
    if (!this.isOpen()) return;
    this.root.classList.remove("open");
    this.root.setAttribute("aria-hidden", "true");
    this.root.innerHTML = "";
    this.panel = null;
    if (this._returnFocus && this._returnFocus.focus) this._returnFocus.focus();
    this._returnFocus = null;
    const cb = this._onClose; this._onClose = null;
    if (cb) cb();
  },
  _trapFocus(e) {
    if (!this.panel) return;
    const focusables = [...this.panel.querySelectorAll('button, a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])')]
      .filter((el) => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0], last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  },
};

/* ===================================================================
   APPOINTMENT DRAWER  (partilhado por Hoje e Agenda)
   =================================================================== */
async function openAppointment(id) {
  Drawer.open(h("div", { class: "drawer-body" }, h("div", { class: "skel", style: "height:120px" })));
  let ag;
  try { ag = await api(`/api/agendamentos/${id}`); }
  catch (e) { toast(e.message, "err"); Drawer.close(); return; }
  renderAppointment(ag);
}

function renderAppointment(ag) {
  const op = ag.op_status || "scheduled";
  const est = (ag.estado || "").toLowerCase();
  const encerrada = ["cancelled", "no_show"].includes(est);
  const totalLabel = ag.preco_por_confirmar ? "Preço a confirmar" : chf(ag.total_centimos);

  const head = h("div", { class: "drawer-head" },
    icon("calendar"),
    h("h3", {}, `Marcação #${ag.id}`),
    h("span", { class: "nav-spacer", style: "flex:1" }),
    h("button", { class: "icon-btn", onclick: () => Drawer.close(), "aria-label": "Fechar" }, icon("x")));

  const cli = ag.cliente_resumo;
  const body = h("div", { class: "drawer-body" },
    h("div", { style: "display:flex;gap:12px;align-items:center;margin-bottom:16px" },
      h("span", { class: "avatar", style: "width:38px;height:38px;font-size:14px" }, initials(ag.nome)),
      h("div", {},
        h("div", { style: "font-weight:600;font-size:15px" }, ag.nome || "Cliente"),
        h("div", { style: "color:var(--text-3);font-size:12.5px" }, ag.telefone || ""))),
    statusBadge(ag.estado, op, ag.bloqueia_horario),
    h("dl", { class: "dl", style: "margin:16px 0" },
      h("dt", {}, "Serviço"), h("dd", {}, ag.servico || "—"),
      h("dt", {}, "Data"), h("dd", {}, ag.data || "—"),
      h("dt", {}, "Hora"), h("dd", { class: "tnum" }, ag.hora || ag.hora_hhmm || "—"),
      h("dt", {}, "Duração"), h("dd", {}, ag.duracao_min ? fmtMin(ag.duracao_min) : (ag.duracao || "—")),
      h("dt", {}, "Preço"), h("dd", {}, totalLabel),
      h("dt", {}, "Estado operacional"), h("dd", {}, OP_LABEL[op] || op),
      ag.reminder_24h ? h("dt", {}, "Reminder 24h") : null,
      ag.reminder_24h ? h("dd", {}, REMINDER_LABEL[ag.reminder_24h.estado] || ag.reminder_24h.estado) : null,
      ag.rebooking_followup ? h("dt", {}, "Próxima manutenção") : null,
      ag.rebooking_followup
        ? h("dd", {}, ag.rebooking_followup.proxima_manutencao
            ? ag.rebooking_followup.proxima_manutencao.split("-").reverse().join(".")
            : "—")
        : null,
      ag.rebooking_followup ? h("dt", {}, "Follow-up") : null,
      ag.rebooking_followup
        ? h("dd", {}, REBOOKING_LABEL[ag.rebooking_followup.estado] || ag.rebooking_followup.estado || "Não configurado")
        : null),
    // P4.1 — pedido de reagendamento pendente (ver notifications/reschedule.py):
    // a marcação acima continua a mostrar a data/hora ORIGINAL — só muda
    // quando o cliente confirmar. Nunca aparece um segundo cartão na Agenda.
    ag.reschedule_pendente ? h("div", { class: "att sev-pending-reschedule", style: "margin-top:14px" },
      icon("clock"),
      h("div", { class: "a-body" },
        h("div", { class: "a-title" }, "Reagendamento pendente ",
          h("span", { class: "badge badge--progress", style: "margin-left:4px" }, "Aguarda cliente")),
        h("div", { class: "a-desc" },
          `Proposto: ${fmtDataPt(ag.reschedule_pendente.new_date)} · ${ag.reschedule_pendente.new_time}`)),
      h("button", { class: "btn btn--sm", onclick: () => cancelarPedidoReagendamentoPrompt(ag) },
        "Cancelar pedido")) : null,
    cli ? h("div", { class: "card card--pad", style: "margin-top:8px" },
      h("div", { class: "eyebrow", style: "margin:0 0 8px" }, "Cliente"),
      h("dl", { class: "dl" },
        h("dt", {}, "Visitas"), h("dd", { class: "tnum" }, String(cli.visits_count ?? 0)),
        h("dt", {}, "Facturado"), h("dd", { class: "tnum" }, chf(cli.billed_cents)),
        h("dt", {}, "Recebido"), h("dd", { class: "tnum" }, chf(cli.paid_cents)),
        h("dt", {}, "Última visita"), h("dd", {}, cli.last_visit ? fmtDataPt(cli.last_visit) : "—"),
        cli.no_show_count ? h("dt", {}, "Faltas") : null,
        cli.no_show_count ? h("dd", { class: "tnum", style: "color:var(--danger)" }, String(cli.no_show_count)) : null)) : null,
    ag.fatura ? h("div", { class: "att sev-info", style: "margin-top:14px" },
      icon("receipt"),
      h("div", { class: "a-body" },
        h("div", { class: "a-title" }, ag.fatura.invoice_number || "Rascunho de fatura"),
        h("div", { class: "a-desc" }, `${chf(ag.fatura.total_cents)} · ${EST_LABEL[ag.fatura.status] || ag.fatura.status}`)),
      h("button", { class: "btn btn--sm", onclick: () => location.hash = "#/faturas" }, "Abrir")) : null);

  // actions
  const foot = h("div", { class: "drawer-foot" });
  const act = async (fn) => { try { await fn(); Drawer.close(); Router.reload(); } catch (e) { handleActionError(e); } };

  if (!encerrada && op !== "done") {
    if (op === "scheduled") {
      foot.append(h("button", { class: "btn", onclick: () => act(() => opTransition(ag.id, "arrived")) }, icon("user-check"), "Chegou"));
      foot.append(h("button", { class: "btn btn--danger", onclick: () => naoCompareceuPrompt(ag) }, "Não compareceu"));
    }
    if (op === "arrived")
      foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => opTransition(ag.id, "in_progress")) }, icon("play"), "Iniciar"));
    if (op === "in_progress" || op === "arrived")
      foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => concluirEFaturar(ag)) }, icon("check"), "Concluir"));
    // Reagendar (atalho, igual ao drag & drop da Agenda) só faz sentido
    // antes de qualquer atendimento em curso — a mesma regra que o backend
    // aplica (OperacaoEmCurso): "arrived"/"in_progress" já não se reagenda.
    // Escondido enquanto há um pedido pendente: o painel só deixa UM pedido
    // de cada vez por marcação (a mesma regra do backend) — "Cancelar
    // pedido", acima, é o único caminho até o pedido atual ser decidido.
    if (op === "scheduled" && !ag.reschedule_pendente)
      foot.append(h("button", { class: "btn", onclick: () => openReagendarRapido(ag) }, icon("clock"), "Reagendar"));
    foot.append(h("button", { class: "btn", onclick: () => openEditAppointment(ag) }, "Editar"));
    foot.append(h("button", { class: "btn btn--danger", onclick: () => cancelarPrompt(ag) }, "Cancelar"));
  } else if (op === "done" && !ag.fatura) {
    foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => gerarFatura(ag)) }, icon("receipt"), "Gerar fatura"));
  } else if (est === "cancelled") {
    // Uma cancelada nunca reabre (não há "Chegou"/"Iniciar"/"Concluir"
    // aqui): "Remarcar" e "Marcar novamente" criam sempre uma marcação
    // NOVA (POST /api/agendamentos) — a cancelada em si fica intacta.
    foot.append(h("button", { class: "btn btn--primary",
      onclick: () => openCreateAppointment({ nome: ag.nome, telefone: ag.telefone, servico_id: ag.servico_id }) },
      icon("calendar"), "Remarcar"));
    foot.append(h("button", { class: "btn",
      onclick: () => openCreateAppointment({ nome: ag.nome, telefone: ag.telefone }) },
      "Marcar novamente"));
  }

  // WhatsApp / Abrir cliente: sempre disponíveis (qualquer estado), para não
  // obrigar a Daniela a ir à página Clientes só para escrever a um cliente.
  if (ag.customer_id) {
    foot.append(h("button", { class: "btn", onclick: () => openCliente(ag.customer_id, "whatsapp") }, icon("sparkles"), "WhatsApp"));
    foot.append(h("button", { class: "btn", onclick: () => openCliente(ag.customer_id) }, "Abrir cliente"));
  }

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" }, head, body, foot));
}

async function opTransition(id, op, confirmar) {
  return jpost(`/api/agendamentos/${id}/op`, { op, confirmar });
}
async function handleActionError(e) {
  if (e.status === 409 && e.body && e.body.precisa_confirmacao) {
    if (confirm(e.body.erro + "\n\nConfirmar mesmo assim?")) return; // caller re-tries with confirmar
  }
  toast(e.message, "err");
}

async function concluirEFaturar(ag) {
  await jpost(`/api/agendamentos/${ag.id}/estado`, { estado: "completed", confirmar: true });
}
async function gerarFatura(ag) {
  let preco = null;
  if (ag.preco_por_confirmar || ag.total_centimos == null) {
    const v = prompt(`Preço deste atendimento (${ag.servico}) em CHF:`, "");
    if (v == null) throw new Error("cancelado");
    const cents = Math.round(parseFloat(v.replace(",", ".")) * 100);
    if (!Number.isFinite(cents) || cents < 0) throw new Error("Preço inválido.");
    preco = cents;
  }
  const inv = await jpost(`/api/agendamentos/${ag.id}/fatura`, preco == null ? {} : { preco_cents: preco });
  toast(`Fatura criada (${chf(inv.total_cents)}) — rascunho`);
}
async function cancelarPrompt(ag) {
  if (!confirm(`Cancelar a marcação de ${ag.nome || "cliente"}?`)) return;
  try { await jpost(`/api/agendamentos/${ag.id}/cancelar`, {}); toast("Cancelada."); Drawer.close(); Router.reload(); }
  catch (e) { toast(e.message, "err"); }
}
// P4.1 — desiste do pedido de reagendamento pendente (nunca da marcação em
// si, que nunca chegou a mudar): liberta o horário novo reservado.
async function cancelarPedidoReagendamentoPrompt(ag) {
  if (!confirm("Cancelar o pedido de reagendamento? A marcação mantém-se no horário atual.")) return;
  try {
    await jpost(`/api/agendamentos/${ag.id}/reagendar-pedido/cancelar`, {});
    toast("Pedido de reagendamento cancelado.");
    Drawer.close(); Router.reload();
  } catch (e) { toast(e.message, "err"); }
}
async function naoCompareceuPrompt(ag) {
  if (!confirm(`Marcar ${ag.nome || "cliente"} como Não compareceu?`)) return;
  const tentar = async (confirmar) => {
    try {
      await jpost(`/api/agendamentos/${ag.id}/estado`, { estado: "no_show", confirmar });
      toast("Marcada como Não compareceu.");
      Drawer.close(); Router.reload();
    } catch (e) {
      if (e.status === 409 && e.body && e.body.precisa_confirmacao && confirm(e.body.erro + "\n\nConfirmar mesmo assim?"))
        return tentar(true);
      toast(e.message, "err");
    }
  };
  await tentar(false);
}

/* ---------- caches partilhadas (evitam pedidos redundantes) ---------- */
let _servicosCache = null;
async function getServicos() {
  if (!_servicosCache) _servicosCache = await api("/api/servicos");
  return _servicosCache;
}
let _clientesCache = null;
async function getClientesCache() {
  if (!_clientesCache) _clientesCache = await api("/api/clientes");
  return _clientesCache;
}
function invalidateClientesCache() { _clientesCache = null; }
const HORA_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

/* ===================================================================
   NOVA MARCAÇÃO — POST /api/agendamentos (reutiliza guardar_agendamento)
   =================================================================== */
async function openCreateAppointment(prefill = {}) {
  let servicos, clientes;
  try { [servicos, clientes] = await Promise.all([getServicos(), getClientesCache()]); }
  catch (e) { toast(e.message, "err"); return; }
  servicos = servicos.filter((s) => s.ativo);

  const f = (label, node) => h("div", { class: "field" }, h("label", {}, label), node);
  const dlId = "dl-clientes-nova";
  const iNome = h("input", { class: "inp", placeholder: "Nome do cliente", list: dlId, autocomplete: "off",
    value: prefill.nome || "" });
  const iTelefone = h("input", { class: "inp", placeholder: "+41 79 000 00 00", type: "tel",
    value: prefill.telefone || "" });
  const datalist = h("datalist", { id: dlId }, clientes.map((c) => h("option", { value: c.name })));
  iNome.addEventListener("input", () => {
    const match = clientes.find((c) => (c.name || "").toLowerCase() === iNome.value.trim().toLowerCase());
    if (match && match.phone) iTelefone.value = match.phone;
  });

  const selServico = h("select", { class: "inp" },
    h("option", { value: "", disabled: true, selected: !prefill.servico_id }, "Escolher serviço…"),
    servicos.map((s) => h("option", { value: s.id, selected: s.id === prefill.servico_id || undefined },
      `${s.nome_pt} · ${fmtMin(s.duracao_min)}` + (s.preco_cents == null ? "" : ` · ${chf(s.preco_cents)}`))));

  const iData = h("input", { class: "inp", type: "date", value: prefill.data || agendaDia });
  const iHora = h("input", { class: "inp", type: "time", value: prefill.hora || "" });
  const iDuracao = h("input", { class: "inp", type: "number", min: 5, max: 600, placeholder: "do serviço" });
  const iPreco = h("input", { class: "inp", type: "number", min: 0, step: "0.05", placeholder: "a confirmar" });
  const iNotas = h("textarea", { class: "inp", rows: 3, style: "resize:vertical" });

  selServico.addEventListener("change", () => {
    const s = servicos.find((x) => x.id === selServico.value);
    if (!s) return;
    iPreco.placeholder = s.preco_cents == null ? "a confirmar" : (s.preco_cents / 100).toFixed(2);
    iDuracao.placeholder = String(s.duracao_min) + " min";
  });

  const body = h("div", { class: "drawer-body" },
    datalist,
    f("Cliente", iNome), f("Telefone", iTelefone),
    f("Serviço", selServico),
    h("div", { style: "display:flex;gap:12px" }, f("Data", iData), f("Hora", iHora)),
    h("div", { style: "display:flex;gap:12px" },
      f("Duração (min)", iDuracao), f("Preço (CHF)", iPreco)),
    f("Notas (opcional)", iNotas));

  const btnGuardar = h("button", { class: "btn btn--primary" }, "Criar marcação");
  const foot = h("div", { class: "drawer-foot" },
    h("button", { class: "btn", onclick: () => Drawer.close() }, "Cancelar"), btnGuardar);

  btnGuardar.addEventListener("click", async () => {
    const nome = iNome.value.trim(), telefone = iTelefone.value.trim();
    if (!nome) { toast("Indica o nome do cliente.", "err"); return; }
    if (!telefone) { toast("Indica o telefone do cliente.", "err"); return; }
    if (!selServico.value) { toast("Escolhe um serviço.", "err"); return; }
    if (!iData.value) { toast("Escolhe uma data.", "err"); return; }
    if (!HORA_RE.test(iHora.value)) { toast("Indica uma hora válida.", "err"); return; }

    const payload = { nome, telefone, servico_id: selServico.value, data: iData.value, hora: iHora.value };
    if (iDuracao.value) payload.duracao_min = Number(iDuracao.value);
    if (iPreco.value.trim() !== "") {
      const cents = Math.round(parseFloat(iPreco.value.replace(",", ".")) * 100);
      if (!Number.isFinite(cents) || cents < 0) { toast("Preço inválido.", "err"); return; }
      payload.preco_cents = cents;
    }
    if (iNotas.value.trim()) payload.notas = iNotas.value.trim();

    btnGuardar.disabled = true;
    try {
      await jpost("/api/agendamentos", payload);
      toast("Marcação criada.");
      invalidateClientesCache();
      Drawer.close();
      Router.reload();
    } catch (e) {
      toast(e.message, "err");
      btnGuardar.disabled = false;
    }
  });

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("calendar"), h("h3", {}, "Nova marcação"),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: () => Drawer.close() }, icon("x"))),
    body, foot));
}

/* ===================================================================
   REAGENDAR (atalho rápido) — P4.1: já NÃO chama /reagendar diretamente.
   Cria um PEDIDO de reagendamento (POST /reagendar-pedido — o MESMO
   endpoint do drag & drop da Agenda, uma única semântica para as duas
   entradas do painel) e propõe o novo horário ao cliente por WhatsApp; a
   marcação original só muda quando ele confirmar (ver
   notifications/reschedule.py). Continua a ser o caminho principal em
   mobile/tablet e para quem prefere não arrastar.
   =================================================================== */
function openReagendarRapido(ag) {
  const f = (label, node) => h("div", { class: "field" }, h("label", {}, label), node);
  const iData = h("input", { class: "inp", type: "date", value: ag.data_iso || "", min: hojeYmdNegocio() });
  const iHora = h("input", { class: "inp", type: "time", value: ag.hora_hhmm || "" });

  const body = h("div", { class: "drawer-body" },
    h("div", { style: "color:var(--text-3);font-size:12.5px;margin-bottom:12px" },
      `${ag.servico || "Serviço"} · ${ag.duracao_min ? fmtMin(ag.duracao_min) : ag.duracao || ""} — a duração mantém-se, só a data/hora mudam. `
      + "A marcação atual mantém-se até o cliente confirmar o novo horário."),
    h("div", { style: "display:flex;gap:12px" }, f("Nova data", iData), f("Nova hora", iHora)));

  const btnEnviar = h("button", { class: "btn btn--primary" }, icon("clock"), "Enviar para confirmação");
  const foot = h("div", { class: "drawer-foot" },
    h("button", { class: "btn", onclick: () => renderAppointment(ag) }, "Voltar"), btnEnviar);

  btnEnviar.addEventListener("click", async () => {
    if (!iData.value || !HORA_RE.test(iHora.value)) { toast("Data e hora são obrigatórias.", "err"); return; }
    if (iData.value === ag.data_iso && iHora.value === ag.hora_hhmm) { Drawer.close(); return; } // no-op
    btnEnviar.disabled = true;
    try {
      // Mesma modal de confirmação do drag & drop (P4.1) — nunca um
      // comportamento diferente consoante a entrada do painel.
      const r = await confirmarReagendamento({
        id: ag.id, nome: ag.nome, servico: ag.servico,
        dataAtualIso: ag.data_iso, horaAtual: ag.hora_hhmm,
        dataNovaIso: iData.value, horaNova: iHora.value,
        origem: "dashboard",
      });
      toast(r.cliente_notificado
        ? "Pedido de reagendamento enviado."
        : "Pedido criado — não foi possível avisar o cliente automaticamente.");
      Drawer.close(); Router.reload();
    } catch (e) {
      btnEnviar.disabled = false;
      if (!e.cancelado) toast(e.message, "err"); // desistiu na modal: fica no drawer para ajustar
    }
  });

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("clock"), h("h3", {}, `Reagendar marcação #${ag.id}`),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: () => Drawer.close() }, icon("x"))),
    body, foot));
}

/* ===================================================================
   EDITAR MARCAÇÃO — /editar (serviço/duração/preço/notas) + /reagendar
   (data/hora), na mesma marcação. Cancelar/concluir/estado operacional/
   cliente/fatura mantêm-se nas suas próprias ações.
   =================================================================== */
async function openEditAppointment(ag) {
  let servicos;
  try { servicos = await getServicos(); }
  catch (e) { toast(e.message, "err"); return; }
  servicos = servicos.filter((s) => s.ativo || s.id === ag.servico_id);

  const f = (label, node) => h("div", { class: "field" }, h("label", {}, label), node);
  const iData = h("input", { class: "inp", type: "date", value: ag.data_iso || "" });
  const iHora = h("input", { class: "inp", type: "time", value: ag.hora_hhmm || "" });
  const selServico = h("select", { class: "inp" },
    servicos.map((s) => h("option", { value: s.id, selected: s.id === ag.servico_id || undefined }, s.nome_pt)));
  const iDuracao = h("input", { class: "inp", type: "number", min: 5, max: 600, value: ag.duracao_min || "" });
  const iPreco = h("input", { class: "inp", type: "number", min: 0, step: "0.05", placeholder: "a confirmar",
    value: ag.preco_cents == null ? "" : (ag.preco_cents / 100).toFixed(2) });
  const iNotas = h("textarea", { class: "inp", rows: 3, style: "resize:vertical" }, ag.extra || "");

  // Data/Hora só ficam editáveis aqui em "scheduled" — a mesma regra do
  // botão "Reagendar" e do drag & drop (op_status arrived/in_progress já
  // tem atendimento em curso, o backend recusa-o sempre). Os restantes
  // campos continuam editáveis em qualquer estado ativo.
  const podeReagendar = (ag.op_status || "scheduled") === "scheduled";
  const body = h("div", { class: "drawer-body" },
    podeReagendar ? h("div", { style: "display:flex;gap:12px" }, f("Data", iData), f("Hora", iHora)) : null,
    f("Serviço", selServico),
    h("div", { style: "display:flex;gap:12px" },
      f("Duração (min)", iDuracao), f("Preço (CHF, vazio = a confirmar)", iPreco)),
    f("Notas", iNotas));

  const btnGuardar = h("button", { class: "btn btn--primary" }, "Guardar alterações");
  const foot = h("div", { class: "drawer-foot" },
    h("button", { class: "btn", onclick: () => renderAppointment(ag) }, "Voltar"), btnGuardar);

  btnGuardar.addEventListener("click", async () => {
    if (!iData.value || !HORA_RE.test(iHora.value)) { toast("Data e hora são obrigatórias.", "err"); return; }
    const patch = {};
    if (selServico.value !== ag.servico_id) patch.servico_id = selServico.value;
    const dur = Number(iDuracao.value);
    if (Number.isFinite(dur) && dur > 0 && dur !== ag.duracao_min) patch.duracao_min = dur;
    const precoTxt = iPreco.value.trim();
    if (precoTxt === "") { if (ag.preco_cents != null) patch.preco_cents = null; }
    else {
      const cents = Math.round(parseFloat(precoTxt.replace(",", ".")) * 100);
      if (!Number.isFinite(cents) || cents < 0) { toast("Preço inválido.", "err"); return; }
      if (cents !== ag.preco_cents) patch.preco_cents = cents;
    }
    const notasTxt = iNotas.value.trim();
    if (notasTxt !== (ag.extra || "")) patch.notas = notasTxt;

    const reagendar = iData.value !== ag.data_iso || iHora.value !== ag.hora_hhmm;
    btnGuardar.disabled = true;
    try {
      if (Object.keys(patch).length) await jpost(`/api/agendamentos/${ag.id}/editar`, patch);
      // P4.1: uma mudança de data/hora aqui é a MESMA coisa que o diálogo
      // "Reagendar" ou o drag & drop — a mesma modal de confirmação, o
      // mesmo pedido, nunca reagenda de imediato (uma única semântica
      // para as três entradas do painel).
      let pedidoEnviado = null;
      if (reagendar) {
        const r = await confirmarReagendamento({
          id: ag.id, nome: ag.nome, servico: ag.servico,
          dataAtualIso: ag.data_iso, horaAtual: ag.hora_hhmm,
          dataNovaIso: iData.value, horaNova: iHora.value,
          origem: "dashboard",
        });
        pedidoEnviado = r.cliente_notificado;
      }
      toast(pedidoEnviado == null ? "Marcação atualizada."
        : pedidoEnviado ? "Marcação atualizada. Pedido de reagendamento enviado."
        : "Marcação atualizada. Pedido de reagendamento criado — não foi possível avisar o cliente automaticamente.");
      Drawer.close(); Router.reload();
    } catch (e) {
      btnGuardar.disabled = false;
      if (e.cancelado) {
        // Desistiu só do reagendamento: os outros campos (se algum mudou)
        // já ficaram guardados acima — a data/hora é que continua igual.
        if (Object.keys(patch).length) { toast("Alterações guardadas. Reagendamento não enviado."); Drawer.close(); Router.reload(); }
        return;
      }
      toast(e.message, "err");
    }
  });

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("calendar"), h("h3", {}, `Editar marcação #${ag.id}`),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: () => Drawer.close() }, icon("x"))),
    body, foot));
}

/* ===================================================================
   VIEW: HOJE
   =================================================================== */
async function viewHoje(mount) {
  setTitle("Hoje", new Date().toLocaleDateString("pt-PT", { timeZone: TZ_NEGOCIO, weekday: "long", day: "numeric", month: "long" }));
  mount.append(skeletonCard());
  let d;
  try { d = await api("/api/painel/hoje"); }
  catch (e) { mount.innerHTML = ""; mount.append(emptyState("Não foi possível carregar: " + e.message)); return; }
  mount.innerHTML = "";

  // 1 — operação atual
  mount.append(cockpitCard(d.cartao));

  // 2 — atenção (agregada)
  const att = d.atencao || [];
  $("#nav-att").hidden = !att.length;
  $("#nav-att").textContent = att.length;
  const pedidosHumano = att.filter((a) => a.tipo === "needs_human").length;
  $("#nav-humano").hidden = !pedidosHumano;
  $("#nav-humano").textContent = pedidosHumano;
  mount.append(h("div", { class: "eyebrow" }, "Precisa da tua atenção"));
  if (!att.length) {
    mount.append(h("div", { class: "att-list" },
      h("div", { class: "att sev-info" }, icon("check"), h("div", { class: "a-body" }, h("div", { class: "a-title" }, "Tudo em dia.")))));
  } else {
    const groups = { agora: [], hoje: [], quando_puder: [] };
    att.forEach((a) => (groups[a.nivel] || groups.quando_puder).push(a));
    for (const [key, label] of [["agora", "Agora"], ["hoje", "Hoje"], ["quando_puder", "Mais tarde"]]) {
      if (!groups[key].length) continue;
      const list = h("div", { class: "att-list" });
      // Aggregate by tipo within each nivel
      const byTipo = {};
      groups[key].forEach((a) => {
        const t = a.tipo || "_single";
        if (!byTipo[t]) byTipo[t] = [];
        byTipo[t].push(a);
      });
      for (const [tipo, items] of Object.entries(byTipo)) {
        if (items.length >= 2 && tipo !== "_single") {
          list.append(attAggregatedRow(tipo, items));
        } else {
          items.forEach((a) => list.append(attRow(a)));
        }
      }
      mount.append(h("div", { class: "att-group" }, h("div", { class: "att-group-lbl" }, label), list));
    }
  }

  // 3 — agenda de hoje (timeline)
  mount.append(h("div", { style: "display:flex;align-items:center;justify-content:space-between;gap:8px;margin:32px 2px 12px" },
    h("div", { class: "eyebrow", style: "margin:0" }, "Agenda de hoje"),
    h("button", { class: "btn btn--sm", onclick: () => openCreateAppointment({ data: hojeYmdNegocio() }) }, icon("calendar"), "Nova marcação")));
  const ag = d.agenda || [];
  if (!ag.length) mount.append(h("div", { class: "card card--pad" }, emptyState("Sem marcações hoje.")));
  else {
    const tl = h("div", { class: "card", style: "padding:6px 10px" });
    ag.forEach((m) => {
      const op = m.op_status || "scheduled";
      tl.append(h("div", { class: `tl-row st-${op} st-${(m.estado || "").toLowerCase()}`, onclick: () => openAppointment(m.id) },
        h("span", { class: "tl-time tnum" }, m.hora),
        h("span", { class: "tl-rail" }),
        h("div", {}, h("div", { class: "tl-name" }, m.cliente),
          h("div", { class: "tl-svc" }, `${m.servico} · ${m.preco_por_confirmar ? "a confirmar" : m.preco_label || ""}`)),
        statusBadge(m.estado, op)));
    });
    mount.append(tl);
  }

  // 4 — resumo do dia
  const r = d.resumo || {};
  mount.append(h("div", { class: "eyebrow" }, "Resumo do dia"));
  mount.append(h("div", { class: "metrics" },
    metric(r.marcacoes ?? 0, "Marcações"),
    metric(r.concluidas ?? 0, "Concluídas"),
    metric(r.receita_por_confirmar ? chf(r.receita_cents) + "+" : chf(r.receita_cents), "Receita", true),
    metric(r.novos_clientes ?? 0, "Novos clientes")));
}

function cockpitCard(ck) {
  ck = ck || { kind: "done" };
  const kind = ck.kind === "in_progress" ? "in_progress" : ck.kind === "next" ? "next" : "idle";
  const card = h("div", { class: `cockpit k-${kind}` });
  const m = ck.marcacao;

  if (ck.kind === "done" || !m) {
    card.append(
      h("span", { class: "badge badge--brand k-badge" }, "Dia terminado"),
      h("h2", {}, "Sem mais marcações hoje"),
      h("div", { class: "k-svc" }, `${ck.marcacoes_hoje || 0} marcação(ões) no total`));
    return card;
  }

  if (ck.kind === "in_progress") {
    // A barra mede o decorrido contra a DURAÇÃO prevista. Antes usava
    // `decorrido + restante` como total — e como o `restante` chega a 0
    // quando passa da hora, a barra ficava eternamente a 100%: mostrava
    // "quase a acabar" tanto aos 5 minutos de atraso como às 3 horas.
    const dur = ck.duracao_min || (ck.decorrido_min || 0) + (ck.restante_min || 0) || 1;
    const pct = Math.min(100, Math.round(((ck.decorrido_min || 0) / dur) * 100));
    const atraso = ck.atraso_min != null ? ck.atraso_min
      : Math.max(0, (ck.decorrido_min || 0) - dur);
    card.append(
      h("span", { class: "badge k-badge", html: '<span class="dot dot--pulse"></span>' + (ck.atrasado ? "Em curso · a passar da hora" : "Em curso") }),
      h("h2", {}, m.cliente),
      h("div", { class: "k-svc" }, m.servico),
      h("div", { class: `k-track${ck.atrasado ? " k-track--over" : ""}` }, h("i", { style: `width:${pct}%` })),
      h("div", { class: "k-meta" },
        h("span", {}, `${ck.inicio} → ${ck.fim_previsto}`),
        h("span", {}, "Decorrido ", h("b", {}, fmtMin(ck.decorrido_min)), ` de ${fmtMin(dur)}`),
        // "Atrasado 0 min" ao lado de "a passar da hora" era a contradição
        // que ela via: agora mostra-se o atraso REAL.
        h("span", {}, ck.atrasado ? "Atrasado " : "Faltam ",
          h("b", {}, fmtMin(ck.atrasado ? atraso : ck.restante_min)))),
      cockpitCta(m, "in_progress"));
    return card;
  }

  // next
  card.append(
    h("span", { class: "badge badge--warning k-badge" }, ck.chegou ? "Próxima · já chegou" : "Próxima cliente"),
    h("h2", {}, m.cliente),
    h("div", { class: "k-svc" }, m.servico),
    h("div", { class: "k-meta", style: "margin-top:10px" },
      h("span", { class: "tnum" }, ck.hora),
      h("span", {}, ck.faltam_min > 0 ? `daqui a ${fmtMin(ck.faltam_min)}` : "agora"),
      h("span", {}, fmtMin(m.duracao_min)),
      h("span", {}, m.preco_por_confirmar ? "Preço a confirmar" : m.preco_label)),
    (m.cliente_visitas != null) ? h("div", { class: "k-client" },
      h("span", {}, `${m.cliente_visitas} visita(s)`),
      m.cliente_ultima_visita ? h("span", {}, `Última ${fmtDataPt(m.cliente_ultima_visita)}`) : null,
      m.cliente_no_shows ? h("span", { style: "color:var(--danger)" }, `${m.cliente_no_shows} falta(s)`) : null) : null,
    cockpitCta(m, ck.chegou ? "arrived" : "scheduled"));
  return card;
}

function cockpitCta(m, op) {
  const wrap = h("div", { class: "k-cta" });
  const run = async (fn) => { try { await fn(); Router.reload(); } catch (e) { toast(e.message, "err"); } };
  if (op === "scheduled")
    wrap.append(h("button", { class: "btn btn--primary", onclick: () => run(() => opTransition(m.id, "arrived")) }, icon("user-check"), "Chegou"));
  if (op === "arrived")
    wrap.append(h("button", { class: "btn btn--primary", onclick: () => run(() => opTransition(m.id, "in_progress")) }, icon("play"), "Iniciar"));
  if (op === "in_progress") {
    wrap.append(h("button", { class: "btn btn--primary", onclick: () => run(() => concluirEFaturar(m)) }, icon("check"), "Concluir"));
    wrap.append(h("button", { class: "btn btn--secondary", disabled: true, title: "Funcionalidade pendente de endpoint backend" }, icon("clock"), "+15 min"));
    if (m.customer_id)
      wrap.append(h("button", { class: "btn btn--secondary", onclick: () => openCliente(m.customer_id) }, icon("user-check"), "Cliente"));
  }
  wrap.append(h("button", { class: "btn btn--subtle", onclick: () => openAppointment(m.id) }, "Marcação"));
  return wrap;
}

function attRow(a) {
  const sev = a.nivel === "agora" ? "sev-agora" : a.nivel === "hoje" ? "sev-hoje" : "sev-info";
  const row = h("div", { class: "att " + sev },
    h("div", { class: "a-body" },
      h("div", { class: "a-title" }, a.titulo),
      a.detalhe ? h("div", { class: "a-desc" }, a.detalhe) : null));
  if (a.acao === "abrir_conversa" && a.telefone)
    row.append(h("button", { class: "btn btn--sm",
      onclick: () => { location.hash = "#/conversas/" + a.telefone; } }, "Abrir conversa"));
  else if (a.appointment_id)
    row.append(h("button", { class: "btn btn--sm", onclick: () => openAppointment(a.appointment_id) }, "Abrir"));
  return row;
}

const ATT_TYPE_LABELS = {
  preco_pendente: (n) => `${n} preços por confirmar`,
  automacao_falhou: (n) => `${n} notificações por enviar`,
  needs_human: (n) => `${n} cliente(s) pediram ajuda`,
  risco_no_show: (n) => `${n} cliente(s) em risco`,
  avaria_sistema: (n) => `${n} avarias no sistema`,
  automacoes_paradas: (n) => `${n} automações paradas`,
};

// Quantos nomes se mostram antes do "e mais N": com 53 nomes em texto
// corrido eram duas páginas de scroll e a contagem, que é a informação que
// interessa, desaparecia. No telemóvel cabe UM nome antes do "e mais N" —
// com três, a linha era cortada com reticências mesmo antes do "e mais",
// que é a parte que dá a dimensão do problema.
const attNomesVisiveis = () =>
  (window.matchMedia && window.matchMedia("(max-width: 560px)").matches) ? 1 : 3;

function attAggregatedRow(tipo, items) {
  const sev = items[0].nivel === "agora" ? "sev-agora" : items[0].nivel === "hoje" ? "sev-hoje" : "sev-info";
  const labelFn = ATT_TYPE_LABELS[tipo];
  const title = labelFn ? labelFn(items.length) : `${items.length} itens`;
  // Extract client names from titles — strip prefix like "Preço por definir — "
  const names = items.map((a) => {
    const raw = a.titulo || "";
    const dash = raw.indexOf(" — ");
    return dash >= 0 ? raw.slice(dash + 3).split(" · ")[0] : raw;
  });
  const visiveis = attNomesVisiveis();
  const restantes = names.length - visiveis;
  const resumo = names.slice(0, visiveis).join(" · ")
    + (restantes > 0 ? ` · e mais ${restantes}` : "");
  const row = h("div", { class: "att " + sev },
    h("div", { class: "a-body" },
      h("div", { class: "a-title" }, title),
      h("div", { class: "a-desc" }, resumo)));
  if (items[0].acao === "abrir_conversa")
    row.append(h("button", { class: "btn btn--sm",
      onclick: () => { location.hash = "#/conversas"; } }, "Ver conversas"));
  else if (items[0].appointment_id)
    row.append(h("button", { class: "btn btn--sm", onclick: () => openAppointment(items[0].appointment_id) }, "Ver"));
  return row;
}

function metric(val, label, accent) {
  return h("div", { class: "metric " + (accent ? "metric--accent" : "") },
    h("div", { class: "m-val tnum" }, String(val)),
    h("div", { class: "m-lbl" }, label));
}

/* ===================================================================
   VIEW: AGENDA  (dia · semana, navegável)
   A vista semanal reutiliza as REGRAS da grelha semanal legada:
   semana começa à segunda-feira, grelha horária vertical com bandas de
   intervalo_min, posicionamento top = (minuto-inicio)*(px/intervalo),
   altura proporcional à duração, repartição de sobrepostos em colunas
   e linha "Agora" só na coluna de hoje. Renderizado no design system
   V2 (tokens, badges, drawer partilhado). Uma única chamada a
   /api/calendario?inicio=&fim= cobre a semana — sem endpoint novo.
   =================================================================== */
let agendaVista = "dia";                                 // "dia" | "semana"
let agendaDia = hojeYmdNegocio();   // âncora (YYYY-MM-DD)
let agGrelha = { hora_inicio: 8, hora_fim: 19, intervalo_min: 30 };  // vem do servidor
let agendaFiltro = "all";
let agendaBusca = "";

const AG_FILTROS = [
  ["all", "Todas"], ["confirmed", "Confirmadas"], ["pending", "Pendentes"],
  ["in_progress", "Em curso"], ["completed", "Concluídas"], ["cancelled", "Canceladas"],
  ["no_show", "Não compareceu"],
];
function matchFiltroAg(e, filtro) {
  const estado = (e.estado_chave || "").toLowerCase();
  if (filtro === "all") {
    // Cancelada que já libertou o horário é ruído na Agenda operacional —
    // só entra em "Todas" quando ainda BLOQUEIA o horário (continua a
    // ocupar o slot, por isso continua a precisar de ser vista). A que
    // libertou só aparece com o filtro "Canceladas" ligado, ou no
    // histórico do cliente.
    return estado !== "cancelled" || !!e.bloqueia_horario;
  }
  if (filtro === "in_progress") return (e.op_status || "") === "in_progress";
  return estado === filtro;
}
function matchBuscaAg(e, q) {
  if (!q) return true;
  return `${e.nome || ""} ${e.telefone || ""} ${e.servico || ""}`.toLowerCase().includes(q);
}

// Legenda de estados — entre os filtros e a grelha (ver .ag-legend em
// app.css). Estática: os 6 estados de negócio/operação da Agenda, na mesma
// cor usada nos cartões (.ag-ev.st-*) e nas badges (statusBadge()). "Chegou"
// (arrived) fica de fora de propósito — é uma transição rápida entre
// Confirmada e Em curso, não um estado em que uma marcação costuma parar.
const AG_LEGENDA = [
  ["confirmed", "Confirmada", "Agendamento confirmado"],
  ["pending", "Pendente", "A aguardar confirmação"],
  ["progress", "Em curso", "Atendimento em andamento"],
  ["success", "Concluída", "Atendimento finalizado"],
  ["cancelled", "Cancelada", "Agendamento cancelado"],
  ["noshow", "Não compareceu", "Cliente não compareceu"],
];
function agLegenda() {
  return h("div", { class: "ag-legend", role: "list", "aria-label": "Legenda de estados da Agenda" },
    AG_LEGENDA.map(([chave, titulo, desc]) =>
      h("div", { class: "ag-legend-item", role: "listitem" },
        h("span", { class: `ag-legend-dot ag-legend-dot--${chave}`, "aria-hidden": "true" }),
        h("div", {},
          h("div", { class: "ag-legend-title" }, titulo),
          h("div", { class: "ag-legend-desc" }, desc)))));
}

const DAY_SHORT = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
function ymdOf(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }

function dateOf(s) {
  if (s instanceof Date) return new Date(s);
  return new Date(String(s).trim() + "T00:00:00");
}
function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
// A semana começa sempre à SEGUNDA-feira (mesma regra do legado).
function mondayOf(anchor) {
  const d = dateOf(anchor);
  const off = (d.getDay() + 6) % 7;   // segunda = 0 … domingo = 6
  return addDays(d, -off);
}
function weekDays(anchor) { const mon = mondayOf(anchor); return Array.from({ length: 7 }, (_, i) => addDays(mon, i)); }

async function viewAgenda(mount) {
  setTitle("Agenda");
  const isWeek = agendaVista === "semana";
  const anchor = isWeek ? ymdOf(mondayOf(agendaDia)) : agendaDia;
  const fim = isWeek ? ymdOf(addDays(dateOf(anchor), 6)) : anchor;

  const nav = h("div", { class: "ag-toolbar" },
    h("div", { class: "ag-nav" },
      h("button", { class: "btn btn--sm", "aria-label": "Anterior", onclick: () => shiftAgenda(-1) }, "‹"),
      h("button", { class: "btn btn--sm", onclick: () => { agendaDia = hojeYmdNegocio(); Router.reload(); } }, "Hoje"),
      h("button", { class: "btn btn--sm", "aria-label": "Seguinte", onclick: () => shiftAgenda(1) }, "›")),
    h("div", { class: "seg", role: "tablist", "aria-label": "Vista da agenda" },
      h("button", { class: (isWeek ? "" : "is-active"), role: "tab", "aria-selected": String(!isWeek), onclick: () => setAgendaVista("dia") }, "Dia"),
      h("button", { class: (isWeek ? "is-active" : ""), role: "tab", "aria-selected": String(isWeek), onclick: () => setAgendaVista("semana") }, "Semana")),
    h("strong", { class: "ag-range tnum" }, agRangeLabel()),
    h("span", { class: "nav-spacer" }),
    h("button", { class: "btn btn--sm btn--primary", onclick: () => openCreateAppointment({ data: agendaDia }) }, icon("calendar"), "Nova marcação"));

  const chipsWrap = h("div", { class: "ag-filtros" });
  function renderChips() {
    chipsWrap.innerHTML = "";
    AG_FILTROS.forEach(([k, l]) => chipsWrap.append(h("button", {
      class: "chip" + (agendaFiltro === k ? " is-active" : ""),
      onclick: () => { agendaFiltro = k; renderChips(); renderList(); },
    }, l)));
  }
  renderChips();

  const searchInp = h("input", { class: "inp ag-search", type: "search",
    placeholder: "Procurar por nome, telefone ou serviço…", value: agendaBusca });
  searchInp.addEventListener("input", () => { agendaBusca = searchInp.value; renderList(); });
  const filterBar = h("div", { class: "ag-filterbar" }, chipsWrap, searchInp);

  mount.append(nav, filterBar, agLegenda(), skeletonCard());

  let d;
  try { d = await api(`/api/calendario?inicio=${anchor}&fim=${fim}`); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  if (d.grelha) agGrelha = { hora_inicio: d.grelha.hora_inicio ?? 8, hora_fim: d.grelha.hora_fim ?? 19, intervalo_min: d.grelha.intervalo_min ?? 30 };

  const listMount = h("div", { class: "ag-list" });
  mount.append(listMount);

  function renderList() {
    const q = agendaBusca.trim().toLowerCase();
    const filtrados = (d.eventos || []).filter((e) => matchFiltroAg(e, agendaFiltro) && matchBuscaAg(e, q));
    const build = () => isWeek
      ? renderSemana(filtrados.filter((e) => e.dia >= anchor && e.dia <= fim))
      : renderDiaGrid(filtrados.filter((e) => e.dia === anchor).sort((a, b) => (a.hora_hhmm || "").localeCompare(b.hora_hhmm || "")), anchor);

    listMount.innerHTML = "";
    listMount.append(build());
    // Altura de banda dinâmica: a 1ª passagem usa o AG_FAIXA da vez anterior
    // só para medir o "chrome" já desenhado por cima da grelha (toolbar,
    // filtros, legenda, cabeçalho de dias em vista semana) — nunca depende
    // das próprias bandas (ver computeAgFaixa). Se o valor ideal para ESTE
    // viewport for diferente, refaz-se a grelha uma única vez já com o
    // valor final, para .ag-hora/.ag-faixa (CSS, var(--ag-faixa)) e
    // agTop()/agH() (JS, cartões posicionados a pixel) nunca desalinharem.
    const weekScroll = listMount.querySelector(".ag-week-scroll");
    if (weekScroll) {
      const ideal = computeAgFaixa(weekScroll);
      if (ideal !== AG_FAIXA) {
        AG_FAIXA = ideal;
        mount.style.setProperty("--ag-faixa", AG_FAIXA + "px");
        listMount.innerHTML = "";
        listMount.append(build());
      }
    }
  }
  renderList();
  // Resize da janela (não é um Router.reload — não refaz o pedido à API):
  // o único propósito é recalcular AG_FAIXA e reconstruir a grelha para o
  // novo viewport. Só ativo enquanto a vista atual continuar a ser Agenda.
  _agendaRelayout = renderList;
}

function setAgendaVista(v) {
  if (agendaVista === v) return;
  agendaVista = v;
  Router.reload();
}
function shiftAgenda(n) {
  const step = agendaVista === "semana" ? 7 : 1;
  const d = dateOf(agendaDia); d.setDate(d.getDate() + step * n);
  agendaDia = ymdOf(d);
  Router.reload();
}

function agRangeLabel() {
  if (agendaVista === "dia") {
    return dateOf(agendaDia).toLocaleDateString("pt-PT", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  }
  const seg = mondayOf(agendaDia), dom = addDays(seg, 6);
  const iniPt = seg.toLocaleDateString("pt-PT", { day: "numeric", month: "long" });
  const fimPt = dom.toLocaleDateString("pt-PT", { day: "numeric", month: "long", year: "numeric" });
  return iniPt + " — " + fimPt;
}

/* ---- clique em espaço vazio + drag & drop (reagendar via /reagendar) ---- */
function faixaHora(i) {
  const min = agGrelha.hora_inicio * 60 + i * (agGrelha.intervalo_min || 30);
  return String(Math.floor(min / 60)).padStart(2, "0") + ":" + String(min % 60).padStart(2, "0");
}
let _dragEv = null;
let _dragEmCurso = false;   // 1 pedido de cada vez — um segundo drop durante o 1º é ignorado

/* ===================================================================
   CONFIRMAÇÃO DE REAGENDAMENTO (P4.1) — modal custom, nunca
   window.confirm(). Única UI de confirmação para as TRÊS entradas do
   painel que criam um pedido de reagendamento (drag & drop na Agenda,
   "Reagendar" no drawer, mudança de data/hora em "Editar"): mesmo
   componente, mesmo endpoint (POST /reagendar-pedido), mesmo texto —
   nunca um comportamento diferente consoante o sítio de onde se veio.
   A marcação original NUNCA muda aqui: isto só cria o PEDIDO, que o
   cliente aceita ou não pelo WhatsApp (ver notifications/reschedule.py).
   `/reagendar` (o endpoint antigo) continua a existir tal e qual: é o
   motor que este pedido usa por baixo quando aceite.

   Devolve uma Promise que resolve com a resposta do POST quando a
   Daniela confirma o envio, ou rejeita com um erro `{ cancelado: true }`
   se ela desistir (X, ESC, backdrop ou botão "Cancelar") — o mesmo
   padrão que gerarFatura() já usa para o prompt() do preço, para os
   chamadores poderem tratar "desistiu" como um simples no-op.
   =================================================================== */
function confirmarReagendamento({ id, nome, servico, dataAtualIso, horaAtual, dataNovaIso, horaNova, origem }) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const settle = (fn, val) => { if (settled) return; settled = true; fn(val); };
    const desistiu = () => Object.assign(new Error("cancelado"), { cancelado: true });

    const box = (label, dataIso, hora) => h("div", { class: "resched-box" },
      h("div", { class: "resched-box-lbl" }, label),
      h("div", { class: "resched-box-data" }, fmtDataPt(dataIso)),
      h("div", { class: "resched-box-hora tnum" }, hora || "—"));

    const btnCancelar = h("button", { class: "btn", onclick: () => Modal.close() }, "Cancelar");
    const btnEnviar = h("button", { class: "btn btn--primary" }, icon("send"), "Enviar pedido");
    const setEnviando = (on) => {
      btnEnviar.disabled = on; btnCancelar.disabled = on; Modal.setClosable(!on); btnClose.disabled = on;
      btnEnviar.innerHTML = ""; btnEnviar.append(icon("send"), on ? "A enviar…" : "Enviar pedido");
    };
    btnEnviar.addEventListener("click", async () => {
      if (btnEnviar.disabled) return; // sem double submit
      setEnviando(true);
      try {
        const r = await jpost(`/api/agendamentos/${id}/reagendar-pedido`,
          { data: dataNovaIso, hora: horaNova, origem });
        settle(resolve, r);
        Modal.close();
      } catch (e) {
        // Falhou: nada foi persistido, a marcação não muda — a modal fica
        // aberta com o erro visível para a Daniela tentar de novo ou desistir.
        setEnviando(false);
        toast(e.message || "Não foi possível criar o pedido de reagendamento.", "err");
      }
    });
    const btnClose = h("button", { class: "icon-btn modal-close", onclick: () => Modal.close(), "aria-label": "Fechar" }, icon("x"));

    const titleId = "resched-title-" + id;
    const panel = h("div", { class: "modal" },
      btnClose,
      h("div", { class: "resched-icon" }, icon("calendar")),
      h("h3", { id: titleId, class: "resched-title" }, "Confirmar reagendamento"),
      h("p", { class: "resched-copy" },
        "Vai ser enviado um pedido de confirmação por WhatsApp. A marcação atual mantém-se até o cliente aceitar o novo horário."),
      h("div", { class: "resched-meta" },
        h("div", {}, h("div", { class: "resched-meta-lbl" }, "Cliente"), h("div", { class: "resched-meta-val" }, nome || "Cliente")),
        h("div", {}, h("div", { class: "resched-meta-lbl" }, "Serviço"), h("div", { class: "resched-meta-val" }, servico || "—"))),
      h("div", { class: "resched-swap" },
        box("Horário atual", dataAtualIso, horaAtual),
        h("span", { class: "resched-arrow", "aria-hidden": "true" }, icon("arrow")),
        box("Novo horário", dataNovaIso, horaNova)),
      h("div", { class: "resched-actions" }, btnCancelar, btnEnviar));

    Modal.open(panel, { labelledby: titleId, onClose: () => settle(reject, desistiu()) });
  });
}

// P4.1 — arrastar já NÃO reagenda de imediato: abre a modal de confirmação
// acima e só cria o PEDIDO (POST /reagendar-pedido, o MESMO endpoint do
// diálogo "Reagendar"/"Editar" — uma única semântica para as três entradas
// do painel) depois de a Daniela confirmar. A marcação original fica
// exatamente onde estava até o cliente confirmar — ver
// notifications/reschedule.py.
async function reagendarDrag(id, data, hora, el, info = {}) {
  if (_dragEmCurso) return;
  const diaTxt = dateOf(data).toLocaleDateString("pt-PT", { weekday: "long", day: "numeric", month: "long" });
  _dragEmCurso = true;
  try {
    const r = await confirmarReagendamento({
      id, nome: info.nome, servico: info.servico,
      dataAtualIso: info.dia, horaAtual: info.hora,
      dataNovaIso: data, horaNova: hora,
      origem: "dashboard_drag",
    });
    toast(r.cliente_notificado
      ? "Pedido de reagendamento enviado."
      : `Pedido criado para ${diaTxt}, ${hora} — não foi possível avisar o cliente automaticamente.`);
    Router.reload();
  } catch (e) {
    // "Cancelar": booking continua exatamente igual, nenhum pedido criado
    // (o drag & drop nunca moveu o DOM otimisticamente, não há nada para
    // repor). Um erro real do POST já mostrou o próprio toast na modal.
    if (!e.cancelado) return;
  } finally {
    _dragEmCurso = false;
  }
}
// Uma faixa vazia é uma célula de fundo: um clique cria uma marcação pré-
// preenchida; um drop reagenda a marcação arrastada para esta hora/dia.
// Cartões de marcação (.ag-ev) ficam por cima e absorvem o próprio clique,
// por isso um clique numa marcação existente NUNCA chega a esta faixa.
function makeFaixa(i, dia) {
  const min = agGrelha.hora_inicio * 60 + i * (agGrelha.intervalo_min || 30);
  const hojeYmd = hojeYmdNegocio();
  const passado = dia < hojeYmd;
  const el = h("div", { class: "ag-faixa" + (min % 60 === 0 ? " hora-cheia" : ""),
    onclick: () => openCreateAppointment({ data: dia, hora: faixaHora(i) }) });
  el.addEventListener("dragover", (e) => {
    if (!_dragEv) return;
    e.preventDefault();
    // Feedback visual só — nunca a decisão: um slot que "parece" livre no
    // browser ainda pode ser recusado pelo motor real no drop (expediente,
    // pausa, conflito). Um dia já passado nunca sequer aceita o drop.
    el.classList.add(passado ? "drop-invalid" : "drop-target");
  });
  el.addEventListener("dragleave", () => el.classList.remove("drop-target", "drop-invalid"));
  el.addEventListener("drop", (e) => {
    e.preventDefault();
    el.classList.remove("drop-target", "drop-invalid");
    if (!_dragEv || passado) { _dragEv = null; return; }
    const novaHora = faixaHora(i);
    // Mesmo slot solto de volta -> no-op, sem pedido nenhum ao servidor.
    if (dia === _dragEv.dia && novaHora === _dragEv.hora) { _dragEv = null; return; }
    reagendarDrag(_dragEv.id, dia, novaHora, _dragEv.el, _dragEv);
    _dragEv = null;
  });
  return el;
}

/* ---- vista DIA (grelha horária de uma coluna — clique/drag como a semana) ---- */
function renderDiaGrid(evs, anchor) {
  const bandas = agBands();
  const hojeYmd = hojeYmdNegocio();
  const eHoje = anchor === hojeYmd;
  const ePassado = anchor < hojeYmd;
  const agoraMin = minutosAgora();
  const dentro = (min) => min >= agGrelha.hora_inicio * 60 && min <= agGrelha.hora_fim * 60;

  const horas = h("div", { class: "ag-hcol" });
  for (let i = 0; i < bandas; i++) {
    const min = agGrelha.hora_inicio * 60 + i * (agGrelha.intervalo_min || 30);
    horas.append(h("div", { class: "ag-hora" }, (min % 60 === 0 ? String(Math.floor(min / 60)).padStart(2, "0") + ":00" : "")));
  }
  // is-past: cabeçalho/coluna ligeiramente mais apagados — só distingue o
  // DIA, nunca as marcações em si (o histórico continua legível). O futuro
  // fica no estilo base (neutro), já claramente distinto do passado.
  const body = h("div", { class: "ag-col" + (eHoje ? " is-today" : ePassado ? " is-past" : ""), "data-dia": anchor });
  for (let i = 0; i < bandas; i++) body.append(makeFaixa(i, anchor));
  agDispor(evs).forEach((p) => body.append(agEventCard(p, eHoje)));
  if (eHoje && dentro(agoraMin)) {
    const agoraTxt = horaAgora();
    body.append(h("div", { class: "ag-now", style: `top:${agTop(agoraMin).toFixed(1)}px`, "aria-hidden": "true" },
      h("span", {}, "Agora · " + agoraTxt)));
  }
  const bodyRow = h("div", { class: "ag-bd ag-bd--dia" }, horas, body);
  const grid = h("div", { class: "ag-grid ag-grid--dia" }, bodyRow);
  if (!evs.length) grid.append(h("div", { class: "empty", style: "padding:14px" }, "Nada agendado neste dia."));
  return h("div", { class: "ag-week-scroll" }, grid);
}

/* ---- vista SEMANA (grelha horária com 7 dias) ---- */
// Altura de banda — deixou de ser um número universal fixo por ecrã
// (§correção de geometria): recalculada por computeAgFaixa() para o
// calendário caber exatamente na altura disponível do viewport, sem
// scroll da página. .ag-hora/.ag-faixa (CSS) leem o mesmo valor via
// var(--ag-faixa) — nunca podem desalinhar do agTop()/agH() (JS).
let AG_FAIXA = 34;
const AG_FAIXA_MIN = 18;   // abaixo disto as horas deixam de ser legíveis
const AG_FAIXA_MAX = 56;   // não esticar mais do que isto em ecrãs muito altos
const AG_BOTTOM_SAFETY = 12; // pequena folga para não colar ao fundo do viewport
// Ponto de entrada do resize da janela (ver viewAgenda) — só recalcula
// layout, nunca refaz o pedido à API.
let _agendaRelayout = null;

// Altura de banda que faz a grelha (cabeçalho + N bandas) caber exatamente
// dentro de .ag-week-scroll, sem scroll interno. weekScroll.clientHeight já
// é o espaço REAL disponível (é um flex child de altura fixa — overflow:auto
// nunca deixa o conteúdo esticá-lo, ver .ag-week-scroll em app.css), por
// isso não depende de somar/adivinhar alturas de toolbar/filtros/legenda:
// só descontar o que fica DENTRO do próprio scroll container e não é banda
// (o padding-bottom dele, a borda do .ag-grid e — em vista semana — o
// cabeçalho .ag-hd).
function computeAgFaixa(weekScroll) {
  const bandas = agBands();
  const cs = getComputedStyle(weekScroll);
  const hd = weekScroll.querySelector(".ag-hd");
  const reservado = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0)
    + 2 // borda superior + inferior do .ag-grid (1px cada)
    + (hd ? hd.getBoundingClientRect().height : 0);
  const disponivel = weekScroll.clientHeight - reservado - AG_BOTTOM_SAFETY;
  const alvo = Math.floor(disponivel / bandas);
  return Math.max(AG_FAIXA_MIN, Math.min(AG_FAIXA_MAX, alvo));
}
function agBands() {
  const { hora_inicio, hora_fim, intervalo_min } = agGrelha;
  return Math.max(1, Math.round(((hora_fim - hora_inicio) * 60) / (intervalo_min || 30)));
}
function agStartMin(ev) {
  const [hh, mm] = (ev.hora_hhmm || "00:00").split(":").map(Number);
  return (hh * 60 + mm) - agGrelha.hora_inicio * 60;
}
function agEndMin(ev) {
  if (ev.fim) {
    const [hh, mm] = String(ev.fim).split("T")[1].slice(0, 5).split(":").map(Number);
    return (hh * 60 + mm) - agGrelha.hora_inicio * 60;
  }
  return agStartMin(ev) + (ev.duracao_minutos || 60);
}
const agTop = (min) => Math.max(0, min) / (agGrelha.intervalo_min || 30) * AG_FAIXA;
// Altura mínima de um cartão. Era 44px "para caber título+serviço+estado",
// mas uma banda de 30 min mede AG_FAIXA (34px no portátil típico): o
// cartão ficava 10px MAIS ALTO do que a sua própria banda e o cartão
// seguinte, desenhado por cima, tapava-lhe o serviço e a badge. O piso
// passa a ser uma linha de texto (AG_EV_MIN) e é o CONTEÚDO que se adapta
// à altura real (ver `compact`/`mini` em agEventCard) — um cartão nunca
// invade a banda de baixo a não ser em marcações de 15 min, e aí só por
// poucos px, abaixo da primeira linha (a hora e o nome ficam sempre à
// vista).
const AG_EV_MIN = 26;
const agH = (dur) => Math.max((dur / (agGrelha.intervalo_min || 30)) * AG_FAIXA, AG_EV_MIN);

// Reparte eventos sobrepostos do mesmo dia por colunas (regra do legado).
function agDispor(evs) {
  const ordenados = evs.slice().sort((a, b) => agStartMin(a) - agStartMin(b));
  const colunas = [], postos = [];
  let grupo = [], grupoFim = -1;
  const fechar = () => {
    const total = Math.max(1, colunas.length);
    grupo.forEach((p) => { p.total = total; });
    grupo = []; colunas.length = 0; grupoFim = -1;
  };
  ordenados.forEach((ev) => {
    const ini = agStartMin(ev);
    const fim = Math.max(ini + 15, agEndMin(ev));
    if (grupo.length && ini >= grupoFim) fechar();
    let col = colunas.findIndex((f) => f <= ini);
    if (col === -1) { colunas.push(fim); col = colunas.length - 1; } else { colunas[col] = fim; }
    const p = { ev, ini, fim, coluna: col, total: 1 };
    postos.push(p); grupo.push(p); grupoFim = Math.max(grupoFim, fim);
  });
  if (grupo.length) fechar();
  return postos;
}

function agEventCard(p, todayCol) {
  const ev = p.ev;
  const op = ev.op_status || "scheduled";
  const estadoKey = (ev.estado_chave || ev.estado || "").toLowerCase();
  const top = agTop(p.ini), altura = agH(p.fim - p.ini);
  const larg = (100 / p.total) - 0.6;
  const left = (100 / p.total) * p.coluna + 3;
  const txt = `${ev.hora_hhmm || "—"} · ${ev.nome || ev.primeiro_nome || "Cliente"}`;
  const sub = [ev.servico, fmtMin(ev.duracao_minutos || 0)].filter(Boolean).join(" · ");
  // Cartão curto demais (< ~45min) para caber hora + nome + serviço + badge
  // sem cortar nada: a badge de estado (e a chip do P4.1, se houver) saem
  // primeiro — hora e serviço nunca desaparecem. Prioridade do redesign:
  // 1 hora, 2 nome, 3 serviço, 4 estado (ver .ag-ev--compact em app.css).
  const compact = altura < 56;
  // Mais curto ainda (bandas pequenas, ecrãs baixos, 15/30 min): só cabe
  // UMA linha. Fica a hora + nome; o serviço vai no title/aria e no drawer.
  const mini = altura < 40;
  // P4.1 — pedido de reagendamento pendente desta marcação, se houver (ver
  // bot.eventos_calendario). É um indício AUXILIAR: nunca muda a cor de
  // estado do cartão (--ev), só acrescenta um sinal violeta à parte.
  const pendente = ev.reschedule_pendente;
  // Reagendar por drag & drop exige uma marcação ainda ativa e SEM
  // atendimento em curso — a mesma regra do backend (op_status
  // arrived/in_progress/done bloqueia em bot.py:reagendar_agendamento,
  // OperacaoEmCurso). Nunca se mostra como arrastável algo que o servidor ia
  // recusar de qualquer forma. A duração nunca é enviada aqui: o drop só
  // muda dia/hora, o backend mantém a duração existente.
  const podeArrastar = !["cancelled", "no_show", "completed"].includes(estadoKey)
    && !["arrived", "in_progress", "done"].includes(op);
  // O cartão continua clicável (abre o drawer) em QUALQUER estado — arrastar
  // é um atalho, nunca o único caminho (drawer -> Editar tem o mesmo
  // reagendamento por data/hora, acessível por teclado e em mobile/tablet
  // onde o drag nativo não é fiável).
  const el = h("button", { class: `ag-ev st-${op} st-${estadoKey}` + (todayCol ? " on-today" : "")
      + (compact ? " ag-ev--compact" : "") + (mini ? " ag-ev--mini" : "") + (pendente ? " has-pending-reschedule" : ""),
    style: `top:${top.toFixed(1)}px;height:${altura.toFixed(1)}px;left:${left.toFixed(2)}%;width:${larg.toFixed(2)}%`,
    // draggable é um atributo ENUMERADO (precisa do valor "true", nunca ""
    // — o helper h() genérico escreve "" para `true`, que o browser trata
    // como não-arrastável; ver core helpers no topo do ficheiro). Corrigido
    // só aqui, sem tocar no comportamento genérico de h() para não arriscar
    // regressão nos outros atributos booleanos usados no dashboard.
    title: `${txt} · ${sub}` + (pendente ? ` · Reagendamento pendente: ${fmtDataPt(pendente.new_date)} ${pendente.new_time}` : ""),
    draggable: podeArrastar ? "true" : undefined, onclick: () => openAppointment(ev.id),
    "aria-label": `${sub} às ${ev.hora_hhmm || "—"}` + (podeArrastar ? " — arrastável para reagendar" : "")
      + (pendente ? " — reagendamento pendente" : "") },
    h("span", { class: "ag-ev-t" }, txt),
    h("span", { class: "ag-ev-s" }, sub),
    statusBadge(ev.estado, op, ev.bloqueia_horario),
    // Chip completa ("Aguarda cliente") quando cabe; no cartão compacto,
    // um ponto no canto chega — o detalhe fica sempre disponível no drawer.
    pendente && !compact ? h("span", { class: "ag-ev-pending" }, icon("clock"), "Aguarda cliente") : null,
    pendente && compact ? h("span", { class: "ag-ev-pending-dot", "aria-hidden": "true" }) : null);
  if (podeArrastar) {
    el.addEventListener("dragstart", (e) => {
      _dragEv = { id: ev.id, dia: ev.dia, hora: ev.hora_hhmm, el, nome: ev.nome || ev.primeiro_nome, servico: ev.servico };
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", String(ev.id));
      el.classList.add("dragging");
    });
    el.addEventListener("dragend", () => { el.classList.remove("dragging"); _dragEv = null; });
  }
  return el;
}

function renderSemana(eventos) {
  const seg = mondayOf(agendaDia);
  const bandas = agBands();
  const hojeYmd = hojeYmdNegocio();
  const agoraMin = minutosAgora();
  const dentro = (min) => min >= agGrelha.hora_inicio * 60 && min <= agGrelha.hora_fim * 60;

  const horas = h("div", { class: "ag-hcol" });
  for (let i = 0; i < bandas; i++) {
    const min = agGrelha.hora_inicio * 60 + i * (agGrelha.intervalo_min || 30);
    horas.append(h("div", { class: "ag-hora" }, (min % 60 === 0 ? String(Math.floor(min / 60)).padStart(2, "0") + ":00" : "")));
  }

  const cols = weekDays(seg).map((dia) => {
    const chave = ymdOf(dia);
    const eHoje = chave === hojeYmd;
    const ePassado = chave < hojeYmd;
    const doDia = eventos.filter((e) => e.dia === chave);
    // is-past: cabeçalho/coluna ligeiramente mais apagados — só distingue o
    // DIA, nunca as marcações em si (o histórico continua legível). O
    // futuro fica no estilo base (neutro), já claramente distinto do passado.
    const body = h("div", { class: "ag-col" + (eHoje ? " is-today" : ePassado ? " is-past" : ""), "data-dia": chave });
    for (let i = 0; i < bandas; i++) body.append(makeFaixa(i, chave));
    agDispor(doDia).forEach((p) => body.append(agEventCard(p, eHoje)));
    // Linha "Agora": só na coluna de hoje, e só quando hoje está na semana e dentro do horário.
    if (eHoje && dentro(agoraMin)) {
      const agoraTxt = horaAgora();
      body.append(h("div", { class: "ag-now", style: `top:${agTop(agoraMin).toFixed(1)}px`, "aria-hidden": "true" },
        h("span", {}, "Agora · " + agoraTxt)));
    }
    return { chave, eHoje, ePassado, body };
  });

  const headerRow = h("div", { class: "ag-hd" },
    h("div", { class: "ag-hd-corner" }),
    cols.map(({ chave, eHoje, ePassado }) =>
      h("div", { class: "ag-hd-dia" + (eHoje ? " is-today" : ePassado ? " is-past" : ""), "data-dia": chave },
        h("span", { class: "ag-hd-wd" }, DAY_SHORT[chave.split("-")[0] && (new Date(chave + "T00:00:00").getDay() + 6) % 7]),
        h("span", { class: "ag-hd-dt tnum" }, chave.slice(8, 10) + "/" + chave.slice(5, 7)),
        eHoje ? h("span", { class: "ag-hd-hoje" }, "hoje") : null)));

  const bodyRow = h("div", { class: "ag-bd" }, horas, cols.map((c) => c.body));
  const grid = h("div", { class: "ag-grid" }, headerRow, bodyRow);
  if (!eventos.length) grid.append(h("div", { class: "empty", style: "padding:14px" }, "Sem marcações nesta semana."));

  return h("div", { class: "ag-week-scroll" }, grid);
}

/* ===================================================================
   VIEW: CLIENTES
   =================================================================== */
async function viewClientes(mount) {
  setTitle("Clientes");
  const search = h("input", { class: "inp", placeholder: "Procurar cliente…", style: "max-width:280px;margin-bottom:16px" });
  mount.append(search, skeletonCard());
  let rows;
  try { rows = await api("/api/clientes"); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  const wrap = h("div", { class: "tbl-wrap" });
  const render = (list) => {
    wrap.innerHTML = "";
    const t = h("table", { class: "tbl" },
      h("thead", {}, h("tr", {},
        h("th", {}, "Cliente"), h("th", {}, "Última visita"), h("th", {}, "Próxima"),
        h("th", { class: "num" }, "Visitas"), h("th", { class: "num" }, "Facturado"),
        h("th", { class: "num" }, "Recebido"))));
    const tb = h("tbody", {});
    list.forEach((c) => tb.append(h("tr", { onclick: () => openCliente(c.id) },
      h("td", {}, h("div", { style: "display:flex;gap:10px;align-items:center" },
        h("span", { class: "avatar" }, initials(c.name)), h("span", {}, c.name || "—"))),
      h("td", {}, c.last_visit ? fmtDataPt(c.last_visit) : "—"),
      h("td", {}, c.next_visit ? fmtDataPt(c.next_visit) : "—"),
      h("td", { class: "num tnum" }, String(c.visits_count ?? 0)),
      h("td", { class: "num tnum" }, chf(c.billed_cents)),
      // por receber sinalizado: é a leitura accionável da tabela
      h("td", { class: "num tnum" + (c.billed_cents > c.paid_cents ? " pay-sum__due" : "") },
        chf(c.paid_cents)))));
    t.append(tb); wrap.append(t);
    if (!list.length) wrap.append(emptyState("Nenhum cliente."));
  };
  render(rows);
  mount.append(wrap);
  search.addEventListener("input", () => {
    const q = search.value.trim().toLowerCase();
    render(rows.filter((c) => (c.name || "").toLowerCase().includes(q)));
  });
}

/* ---------- Client Manager: helpers ---------- */
function fmtDataHoraPt(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  return d.toLocaleDateString("pt-PT", { day: "2-digit", month: "short" }) + " · " +
    d.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
}

function clientTagsRow(c) {
  const tags = [];
  if (c.vip) tags.push(h("span", { class: "badge badge--brand" }, "VIP"));
  const visitas = c.visits_count ?? 0;
  if (visitas === 0) tags.push(h("span", { class: "badge" }, "Nova cliente"));
  else if (visitas >= 2) tags.push(h("span", { class: "badge badge--info" }, "Recorrente"));
  (c.tags || []).forEach((t) => tags.push(h("span", { class: "badge" }, t)));
  return tags.length ? h("div", { style: "display:flex;gap:6px;flex-wrap:wrap;margin-top:6px" }, tags) : null;
}

// Marcação ativa mais próxima (hoje ou futuro, não cancelada/faltou) — usada
// para gating das ações rápidas e para pré-preencher o composer.
function proximaMarcacaoDoCliente(historico) {
  const hoje = hojeYmdNegocio();
  const ativas = (historico || []).filter((m) =>
    m.data_iso && m.data_iso >= hoje && m.op_status !== "done" &&
    !["cancelled", "no_show"].includes((m.estado || "").toLowerCase()));
  ativas.sort((a, b) => (a.data_iso + (a.hora_hhmm || "")).localeCompare(b.data_iso + (b.hora_hhmm || "")));
  return ativas[0] || null;
}

const EVENT_LABEL = { "customer.created": "Cliente registado", "message.manual_sent": "Mensagem enviada" };

// Checklist do pós-atendimento (P0) para uma visita — dados já vêm prontos
// de /api/clientes/<id> (agendamento + fatura associada), nada é recalculado
// aqui. Devolve null quando a visita nem chegou a "done".
function checklistPosAtendimento(m) {
  if (m.op_status !== "done" && !m.completed_at) return null;
  const linhas = ["✓ Serviço concluído"];
  const f = m.fatura;
  if (f) {
    linhas.push(`✓ ${chf(f.total_cents)}`);
    if (f.payment_method) linhas.push(`✓ Pago em ${f.payment_method === "cash" ? "Cash" : f.payment_method}`);
    if (f.invoice_number) linhas.push(`✓ Fatura #${f.invoice_number}`);
    if (f.pdf_sent_at) linhas.push("✓ PDF enviado");
  }
  if (m.feedback_requested_at) linhas.push("✓ Feedback solicitado");
  return linhas;
}

// Timeline compacta: junta o histórico de marcações (já persistido) com os
// eventos da outbox sobre este cliente (registo/mensagens) — nunca inventa
// um transcript de conversa, só o que já está guardado.
function timelineDoCliente(historico, eventos) {
  const itens = [];
  (historico || []).forEach((m) => {
    const checklist = checklistPosAtendimento(m);
    itens.push({
      chave: (m.data_iso || "0000-00-00") + "T" + (m.hora_hhmm || "00:00"),
      node: h("div", { class: "tl-row", style: "grid-template-columns:70px 1fr auto", onclick: () => openAppointment(m.id) },
        h("span", { class: "tl-time" }, fmtDataPt(m.data_iso)),
        h("div", {},
          h("div", { class: "tl-name" }, m.servico),
          h("div", { class: "tl-svc" }, m.hora || ""),
          checklist ? h("div", { class: "tl-svc", style: "margin-top:2px" }, checklist.join(" · ")) : null,
          m.feedback_text ? h("div", { class: "tl-svc", style: "font-style:italic" }, `Feedback: "${m.feedback_text}"`) : null),
        statusBadge(m.estado, m.op_status)),
    });
  });
  (eventos || []).forEach((e) => {
    const label = EVENT_LABEL[e.type];
    if (!label) return;
    const desc = e.type === "message.manual_sent" ? ((e.payload && e.payload.texto) || "") : "";
    itens.push({
      chave: e.created_at || "0000-00-00",
      node: h("div", { class: "tl-row", style: "grid-template-columns:70px 1fr auto" },
        h("span", { class: "tl-time" }, fmtDataHoraPt(e.created_at)),
        h("div", {}, h("div", { class: "tl-name" }, label), desc ? h("div", { class: "tl-svc" }, desc.slice(0, 60)) : null),
        icon(e.type === "message.manual_sent" ? "sparkles" : "users")),
    });
  });
  itens.sort((a, b) => b.chave.localeCompare(a.chave));
  return itens.map((i) => i.node);
}

function clientComposer(c, proxima) {
  const textarea = h("textarea", { class: "inp", rows: 3, style: "resize:vertical",
    placeholder: "Escrever mensagem…" });
  const preencher = (txt) => { textarea.value = txt; textarea.focus(); };
  const detalhes = () => `${proxima.servico}, ${fmtDataPt(proxima.data_iso)} às ${proxima.hora_hhmm || proxima.hora}`;
  // Atalhos conforme o estado da próxima marcação — "pending" ainda pode
  // pedir confirmação; "confirmed" já não (só lembrar/detalhar/avisar
  // atraso); cancelled/completed/no_show (ou sem próxima) não mostram
  // nenhum atalho de confirmação/reminder de marcação ativa.
  const estado = (proxima && proxima.estado || "").toLowerCase();
  const botoes = [];
  if (estado === "pending") {
    botoes.push(h("button", { class: "btn btn--sm",
      onclick: () => preencher(`Confirmo a sua marcação: ${detalhes()}. ✨`) },
      "Confirmar horário"));
  } else if (estado === "confirmed") {
    botoes.push(h("button", { class: "btn btn--sm",
      onclick: () => preencher(`Só a lembrar a sua marcação: ${detalhes()}. 📅`) },
      "Relembrar marcação"));
    botoes.push(h("button", { class: "btn btn--sm",
      onclick: () => preencher(`Os detalhes da sua marcação: ${detalhes()}. 💌`) },
      "Enviar detalhes"));
    botoes.push(h("button", { class: "btn btn--sm",
      onclick: () => preencher("Vamos atrasar-nos alguns minutos — obrigada pela paciência!") },
      "Avisar atraso"));
  }
  botoes.push(h("button", { class: "btn btn--sm", onclick: () => preencher("") }, "Escrever outra"));
  const rapidas = h("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin:10px 0" }, botoes);
  const btnEnviar = h("button", { class: "btn btn--primary btn--sm" }, "Enviar mensagem");
  btnEnviar.addEventListener("click", async () => {
    const texto = textarea.value.trim();
    if (!texto) { toast("Escreva uma mensagem antes de enviar.", "err"); return; }
    btnEnviar.disabled = true;
    try {
      const r = await jpost(`/api/clientes/${c.id}/mensagem`, { texto });
      if (r.demo) toast("Cliente demo — mensagem registada, envio real ao WhatsApp desativado.");
      else toast("Mensagem enviada.");
      textarea.value = "";
    } catch (e) { toast(e.message, "err"); }
    finally { btnEnviar.disabled = false; }
  });
  return h("div", { class: "card card--pad", style: "margin-top:8px;display:none" },
    h("div", { class: "eyebrow", style: "margin:0 0 8px" }, "WhatsApp"),
    textarea, rapidas, btnEnviar);
}

function clientNotesSection(c, refresh) {
  const view = h("div", { style: "white-space:pre-wrap;color:var(--text-2);font-size:13px" },
    c.notes_internal || "Sem notas.");
  const btnEditar = h("button", { class: "btn btn--sm" }, "Editar");
  const head = h("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:8px" },
    h("div", { class: "eyebrow", style: "margin:0" }, "Notas internas"), btnEditar);
  const box = h("div", { class: "card card--pad", style: "margin-top:8px" }, head, view);
  btnEditar.addEventListener("click", () => {
    const textarea = h("textarea", { class: "inp", rows: 4, style: "resize:vertical" }, c.notes_internal || "");
    const btnGuardar = h("button", { class: "btn btn--primary btn--sm" }, "Guardar");
    const btnCancelar = h("button", { class: "btn btn--sm" }, "Cancelar");
    view.replaceWith(h("div", {}, textarea, h("div", { style: "display:flex;gap:8px;margin-top:8px" }, btnGuardar, btnCancelar)));
    head.replaceChildren(h("div", { class: "eyebrow", style: "margin:0" }, "Notas internas"));
    btnGuardar.addEventListener("click", async () => {
      btnGuardar.disabled = true;
      try {
        await jpatch(`/api/clientes/${c.id}`, { notes_internal: textarea.value.trim() });
        toast("Notas guardadas.");
        refresh();
      } catch (e) { toast(e.message, "err"); btnGuardar.disabled = false; }
    });
    btnCancelar.addEventListener("click", () => refresh());
  });
  return box;
}

// P4.1 — Reagendar a partir do Client Manager. Antes chamava /reagendar
// diretamente (via dois prompt() nativos) e mudava a marcação de imediato,
// contornando o pedido de confirmação por WhatsApp — inconsistente com o
// drag & drop e o "Reagendar" da Agenda. Agora é a MESMA semântica: só
// recolhe a nova data/hora (UI mínima própria, um drawer simples — nada de
// prompt()), depois abre a MESMA modal de confirmação (confirmarReagendamento,
// já usada pela Agenda) e cria o MESMO pedido (POST /reagendar-pedido).
// Nenhuma modal nova, nenhum endpoint novo.
function reagendarClienteDrawer(cliente, ag) {
  const f = (label, node) => h("div", { class: "field" }, h("label", {}, label), node);
  const iData = h("input", { class: "inp", type: "date", value: ag.data_iso || "", min: hojeYmdNegocio() });
  const iHora = h("input", { class: "inp", type: "time", value: ag.hora_hhmm || "" });
  const voltar = () => openCliente(cliente.id);

  const body = h("div", { class: "drawer-body" },
    h("div", { style: "color:var(--text-3);font-size:12.5px;margin-bottom:12px" },
      `${ag.servico || "Serviço"} — a duração mantém-se, só a data/hora mudam. `
      + "A marcação atual mantém-se até o cliente confirmar o novo horário."),
    h("div", { style: "display:flex;gap:12px" }, f("Nova data", iData), f("Nova hora", iHora)));

  const btnEnviar = h("button", { class: "btn btn--primary" }, icon("clock"), "Enviar para confirmação");
  const foot = h("div", { class: "drawer-foot" },
    h("button", { class: "btn", onclick: voltar }, "Voltar"), btnEnviar);

  btnEnviar.addEventListener("click", async () => {
    if (!iData.value || !HORA_RE.test(iHora.value)) { toast("Data e hora são obrigatórias.", "err"); return; }
    if (iData.value === ag.data_iso && iHora.value === ag.hora_hhmm) { voltar(); return; } // no-op
    btnEnviar.disabled = true;
    try {
      const r = await confirmarReagendamento({
        id: ag.id, nome: cliente.name, servico: ag.servico,
        dataAtualIso: ag.data_iso, horaAtual: ag.hora_hhmm,
        dataNovaIso: iData.value, horaNova: iHora.value,
        origem: "dashboard",
      });
      toast(r.cliente_notificado
        ? "Pedido de reagendamento enviado."
        : "Pedido criado — não foi possível avisar o cliente automaticamente.");
      invalidateClientesCache();
      voltar(); // reabre o Client Manager já com "Reagendamento pendente"
    } catch (e) {
      btnEnviar.disabled = false;
      if (!e.cancelado) toast(e.message, "err"); // desistiu na modal: fica aqui para ajustar
    }
  });

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("clock"), h("h3", {}, `Reagendar marcação #${ag.id}`),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: voltar }, icon("x"))),
    body, foot));
}

function clientQuickActions(c, proxima, composerNode) {
  const foot = h("div", { class: "drawer-foot" });
  const act = async (fn) => { try { await fn(); invalidateClientesCache(); Drawer.close(); Router.reload(); } catch (e) { handleActionError(e); } };

  foot.append(h("button", { class: "btn", onclick: () => {
    const visivel = composerNode.style.display !== "none";
    composerNode.style.display = visivel ? "none" : "";
    if (!visivel) { composerNode.scrollIntoView({ behavior: "smooth", block: "nearest" }); $("textarea.inp", composerNode).focus(); }
  } }, icon("sparkles"), "WhatsApp"));
  foot.append(h("button", { class: "btn", onclick: () => openCreateAppointment({ nome: c.name, telefone: c.phone }) }, icon("calendar"), "Nova marcação"));

  if (proxima) {
    const op = proxima.op_status || "scheduled";
    // Mesma regra do backend (OperacaoEmCurso) e da Agenda: só se reagenda
    // uma marcação "scheduled" sem já ter um pedido pendente — "Cancelar
    // pedido", no bloco acima, é o único caminho até o pedido atual ser
    // decidido.
    if (op === "scheduled" && !proxima.reschedule_pendente)
      foot.append(h("button", { class: "btn", onclick: () => reagendarClienteDrawer(c, proxima) }, icon("clock"), "Reagendar"));
    foot.append(h("button", { class: "btn btn--danger",
      onclick: () => act(() => jpost(`/api/agendamentos/${proxima.id}/cancelar`, {})) }, icon("x"), "Cancelar"));
    if (op === "scheduled")
      foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => opTransition(proxima.id, "arrived")) }, icon("user-check"), "Chegou"));
    if (op === "arrived")
      foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => opTransition(proxima.id, "in_progress")) }, icon("play"), "Iniciar"));
    if (op === "in_progress" || op === "arrived")
      foot.append(h("button", { class: "btn btn--primary", onclick: () => act(() => jpost(`/api/agendamentos/${proxima.id}/estado`, { estado: "completed", confirmar: true })) }, icon("check"), "Concluir"));
  }
  return foot;
}

async function openCliente(id, foco) {
  Drawer.open(h("div", { class: "drawer-body" }, h("div", { class: "skel", style: "height:140px" })));
  let d;
  try { d = await api(`/api/clientes/${id}`); }
  catch (e) { toast(e.message, "err"); Drawer.close(); return; }
  const c = d.cliente;
  const historico = d.historico || [];
  const proxima = proximaMarcacaoDoCliente(historico);
  const refresh = () => openCliente(id);
  const composerNode = clientComposer(c, proxima);
  if (foco === "whatsapp") composerNode.style.display = "";

  const head = h("div", { class: "drawer-head" },
    h("span", { class: "avatar", style: "width:38px;height:38px;font-size:14px" }, initials(c.name)),
    h("div", {},
      h("h3", { style: "margin:0" }, c.name || "Cliente"),
      h("div", { style: "color:var(--text-3);font-size:12.5px" }, c.phone || "")),
    h("span", { style: "flex:1" }),
    h("button", { class: "icon-btn", onclick: () => Drawer.close(), "aria-label": "Fechar" }, icon("x")));

  const body = h("div", { class: "drawer-body" },
    clientTagsRow(c),
    // P5 — consentimento CANÓNICO de marketing (ver migração 20): não existe
    // nenhuma recolha automática, por isso este toggle manual é o único
    // caminho para tornar um cliente elegível a uma campanha (ver
    // #/campanhas). Nunca ligado por omissão.
    h("div", { style: "margin-top:10px;display:flex;align-items:center;gap:8px;flex-wrap:wrap" },
      h("span", { class: "badge " + (c.marketing_opt_in ? "badge--info" : "") },
        icon("megaphone"), c.marketing_opt_in ? "Consentimento de marketing: sim" : "Sem consentimento de marketing"),
      h("button", { class: "btn btn--sm", onclick: async () => {
        try { await jpatch(`/api/clientes/${c.id}`, { marketing_opt_in: !c.marketing_opt_in }); refresh(); }
        catch (e) { toast(e.message, "err"); }
      } }, c.marketing_opt_in ? "Revogar" : "Marcar como consentido")),
    h("div", { class: "metrics", style: "margin-top:14px" },
      metric(c.visits_count ?? 0, "Visitas"),
      metric(chf(c.billed_cents), "Facturado"),
      metric(chf(c.paid_cents), "Recebido"),
      metric(c.last_visit ? fmtDataPt(c.last_visit) : "—", "Última visita"),
      metric(c.next_visit ? fmtDataPt(c.next_visit) : "—", "Próxima")),

    proxima ? h("div", { class: "att sev-info", style: "margin-top:14px" },
      icon("calendar"),
      h("div", { class: "a-body" },
        h("div", { class: "a-title" }, proxima.servico),
        h("div", { class: "a-desc" }, `${fmtDataPt(proxima.data_iso)} · ${proxima.hora_hhmm || proxima.hora} · ${OP_LABEL[proxima.op_status || "scheduled"]}`)),
      h("button", { class: "btn btn--sm", onclick: () => openAppointment(proxima.id) }, "Abrir")) : null,

    // P4.1 — mesmo bloco "Reagendamento pendente" da marcação (ver
    // renderAppointment): a próxima marcação continua a mostrar a data/hora
    // ORIGINAL aqui em cima — só muda quando o cliente confirmar.
    proxima && proxima.reschedule_pendente ? h("div", { class: "att sev-pending-reschedule", style: "margin-top:14px" },
      icon("clock"),
      h("div", { class: "a-body" },
        h("div", { class: "a-title" }, "Reagendamento pendente ",
          h("span", { class: "badge badge--progress", style: "margin-left:4px" }, "Aguarda cliente")),
        h("div", { class: "a-desc" },
          `Proposto: ${fmtDataPt(proxima.reschedule_pendente.new_date)} · ${proxima.reschedule_pendente.new_time}`)),
      h("button", { class: "btn btn--sm", onclick: () => cancelarPedidoReagendamentoPrompt(proxima) },
        "Cancelar pedido")) : null,

    historico[0] && historico[0].servico_id ? h("button", {
      class: "btn btn--sm", style: "margin-top:12px",
      onclick: () => openCreateAppointment({ nome: c.name, telefone: c.phone, servico_id: historico[0].servico_id }),
    }, "Repetir último serviço") : null,

    composerNode,
    clientNotesSection(c, refresh),

    h("div", { class: "eyebrow" }, "Faturas"),
    (d.faturas && d.faturas.length)
      ? h("div", {}, d.faturas.map((f) => h("div", { class: "att sev-info" },
        icon("receipt"),
        h("div", { class: "a-body" },
          h("div", { class: "a-title" }, f.invoice_number || "Rascunho"),
          h("div", { class: "a-desc" }, `${fmtDataPt(f.issue_date || (f.created_at || "").slice(0, 10))} · ${chf(f.total_cents)} · ${EST_LABEL[f.status] || f.status}`)))))
      : h("div", { class: "empty", style: "padding:16px" }, "Sem faturas."),

    h("div", { class: "eyebrow" }, "Histórico"));

  const timelineTodas = timelineDoCliente(historico, d.eventos);
  const timelineEl = h("div", { class: "timeline" }, timelineTodas.slice(0, 5));
  body.append(timelineEl);
  if (timelineTodas.length > 5) {
    const btnVerTudo = h("button", { class: "btn btn--sm", style: "margin-top:10px" }, "Ver histórico completo");
    btnVerTudo.addEventListener("click", () => {
      timelineEl.innerHTML = "";
      timelineEl.append(...timelineTodas);
      btnVerTudo.remove();
    });
    body.append(btnVerTudo);
  }
  if (!timelineTodas.length) body.append(h("div", { class: "empty", style: "padding:16px" }, "Sem atividade registada."));

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    head, body, clientQuickActions(c, proxima, composerNode)));
  if (foco === "whatsapp") {
    composerNode.scrollIntoView({ behavior: "smooth", block: "nearest" });
    $("textarea.inp", composerNode).focus();
  }
}

/* ===================================================================
   VIEW: SERVIÇOS
   =================================================================== */
async function viewServicos(mount) {
  setTitle("Serviços");
  mount.append(skeletonCard());
  let list;
  try { list = await api("/api/servicos"); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  const box = h("div", { class: "card", style: "padding:4px 6px" });
  list.forEach((s) => {
    box.append(h("div", { class: "tl-row", style: "grid-template-columns:1fr auto auto", onclick: () => editServico(s) },
      h("div", {}, h("div", { class: "tl-name" }, s.nome_pt),
        h("div", { class: "tl-svc" }, fmtMin(s.duracao_min))),
      h("span", { class: "tnum", style: "color:var(--text-2)" }, s.preco_cents == null ? "Preço a confirmar" : chf(s.preco_cents)),
      h("span", { class: "badge " + (s.ativo ? "badge--success" : "") }, s.ativo ? "Ativo" : "Inativo")));
  });
  mount.append(box);
}
function editServico(s) {
  const f = (name, val, attrs = {}) => h("div", { class: "field" }, h("label", {}, name),
    h("input", Object.assign({ class: "inp", value: val ?? "", "data-k": attrs.k }, attrs)));
  // P2 — follow-up automático (rebooking): reutiliza rebook_days já
  // existente ("de quantos em quantos dias sugerir outra vez") + o
  // interruptor follow_up_enabled (por omissão desligado — ver migração 17).
  const followUpToggle = h("label", { class: "field", style: "display:flex;gap:8px;align-items:center" },
    h("input", { type: "checkbox", "data-k": "follow_up_enabled", checked: s.follow_up_enabled || undefined }),
    h("span", {}, "Follow-up automático (rebooking)"));
  const body = h("div", { class: "drawer-body" },
    f("Nome (PT)", s.nome_pt, { k: "nome_pt" }),
    f("Duração (min)", s.duracao_min, { k: "duracao_min", type: "number", min: 5, max: 600 }),
    f("Preço (cêntimos, vazio = a confirmar)", s.preco_cents ?? "", { k: "preco_cents", type: "number", min: 0 }),
    f("Buffer antes (min)", s.buffer_before_min ?? 0, { k: "buffer_before_min", type: "number", min: 0 }),
    f("Buffer depois (min)", s.buffer_after_min ?? 0, { k: "buffer_after_min", type: "number", min: 0 }),
    followUpToggle,
    f("Próxima manutenção (dias)", s.rebook_days ?? "", { k: "rebook_days", type: "number", min: 1 }));
  const foot = h("div", { class: "drawer-foot" },
    h("button", { class: "btn btn--primary", onclick: async (ev) => {
      const patch = {};
      $$("input[data-k]", body).forEach((i) => {
        if (i.type === "checkbox") { patch[i.dataset.k] = i.checked; return; }
        if (i.value !== "") patch[i.dataset.k] = i.type === "number" ? Number(i.value) : i.value;
      });
      if ($("input[data-k=preco_cents]", body).value === "") patch.preco_cents = null;
      try { await jpatch(`/api/servicos/${s.id}`, patch); toast("Serviço atualizado."); Drawer.close(); Router.reload(); }
      catch (e) { toast(e.message, "err"); }
    } }, "Guardar"));
  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("sparkles"), h("h3", {}, s.nome_pt),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: () => Drawer.close() }, icon("x"))),
    body, foot));
}

/* ===================================================================
   VIEW: HORÁRIOS
   =================================================================== */
const DIAS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];
async function viewHorarios(mount) {
  setTitle("Horários");
  mount.append(skeletonCard());
  let d;
  try { d = await api("/api/horarios"); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  const grelha = d.grelha || [];
  const box = h("div", { class: "card", style: "padding:4px 6px" });
  DIAS.forEach((nome, wd) => {
    const dia = grelha.find((g) => g.weekday === wd) || {};
    const aberto = dia.opens && dia.closes;
    box.append(h("div", { class: "tl-row", style: "grid-template-columns:110px 1fr" },
      h("div", { class: "tl-name" }, nome),
      aberto
        ? h("div", { class: "tnum", style: "color:var(--text-2)" }, `${dia.opens} – ${dia.closes}` + (dia.break_start ? `  ·  pausa ${dia.break_start}–${dia.break_end}` : ""))
        : h("span", { class: "badge" }, "Fechado")));
  });
  mount.append(box);
  const exc = d.excecoes || [];
  mount.append(h("div", { class: "eyebrow" }, "Exceções / ausências"));
  if (!exc.length) mount.append(h("div", { class: "empty", style: "padding:14px" }, "Sem exceções."));
  else mount.append(h("div", { class: "card", style: "padding:4px 6px" }, exc.map((e) => h("div", { class: "tl-row", style: "grid-template-columns:1fr auto" },
    h("div", {}, h("div", { class: "tl-name" }, fmtDataPt(e.day || e.data_inicio)), h("div", { class: "tl-svc" }, e.reason || "")),
    h("span", { class: "badge " + (e.closed ? "badge--danger" : "") }, e.closed ? "Fechado" : "Horário especial")))));
  mount.append(h("p", { class: "empty", style: "text-align:left;padding:16px 2px" },
    "Edição de horários e exceções: próxima iteração."));
}

/* ===================================================================
   VIEW: FATURAS
   =================================================================== */
let faturaFiltro = "all";
async function viewFaturas(mount) {
  setTitle("Faturas");
  const filtros = h("div", { class: "tabs" });
  [["all", "Todas"], ["draft", "Rascunho"], ["issued", "Emitidas"], ["partial", "Parciais"],
   ["paid", "Pagas"], ["overdue", "Vencidas"], ["cancelled", "Anuladas"]]
    .forEach(([k, l]) => filtros.append(h("button", { class: "tab " + (faturaFiltro === k ? "is-active" : ""), onclick: () => { faturaFiltro = k; Router.reload(); } }, l)));
  mount.append(filtros, skeletonCard());
  let list;
  try { list = await api("/api/faturas?estado=" + faturaFiltro); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  if (!list.length) { mount.append(h("div", { class: "card card--pad" }, emptyState("Nenhuma fatura."))); return; }
  const wrap = h("div", { class: "tbl-wrap" },
    h("table", { class: "tbl" },
      h("thead", {}, h("tr", {}, h("th", {}, "#"), h("th", {}, "Cliente"), h("th", {}, "Data"),
        h("th", { class: "num" }, "Total"), h("th", { class: "num" }, "Por receber"), h("th", {}, "Estado"))),
      h("tbody", {}, list.map((f) => h("tr", { onclick: () => openFatura(f.id) },
        h("td", { class: "tnum" }, f.invoice_number || "—"),
        h("td", {}, f.customer_name_snapshot || "—"),
        h("td", {}, fmtDataPt(f.issue_date || (f.created_at || "").slice(0, 10))),
        h("td", { class: "num tnum" }, chf(f.total_cents)),
        // Só quem já deve dinheiro aparece aqui: um RASCUNHO ainda não se deve
        // a ninguém, e uma anulada deixou de se dever. Coluna de zeros = ruído.
        (() => {
          const deve = (f.status === "issued" || f.status === "partial") && f.due_cents > 0;
          return h("td", { class: "num tnum" + (deve ? " pay-sum__due" : "") },
            deve ? chf(f.due_cents) : "—");
        })(),
        h("td", {}, invoiceBadge(f.status, f.due_date)))))));
  mount.append(wrap);
}
function invoiceBadge(status, due) {
  if (status === "issued" && due && due < hojeYmdNegocio())
    return h("span", { class: "badge badge--danger" }, "Vencida");
  if (status === "partial" && due && due < hojeYmdNegocio())
    return h("span", { class: "badge badge--danger" }, "Vencida · parcial");
  const map = { draft: ["", "Rascunho"], issued: ["badge--info", "Emitida"],
                partial: ["badge--warning", "Pagamento parcial"],
                paid: ["badge--success", "Paga"], cancelled: ["", "Anulada"] };
  const [c, l] = map[status] || ["", status];
  return h("span", { class: "badge " + c }, l);
}
const METODO_PAGAMENTO_LABEL = {
  cash: "Numerário", twint: "TWINT", card: "Cartão",
  transfer: "Transferência", other: "Outro",
};

/* Recebido / Por receber + lista de pagamentos + formulário de registo.
   O valor sugerido é sempre o que FALTA — o caso normal é fechar a conta de
   uma vez, e assim isso é um clique só. */
function blocoPagamentos(f, recarregar) {
  const recebido = f.paid_cents || 0;
  const falta = f.due_cents != null ? f.due_cents : Math.max(0, (f.total_cents || 0) - recebido);
  const pagamentos = f.payments || [];
  const fechada = f.status === "cancelled" || f.status === "draft";

  const resumo = h("div", { class: "pay-sum" },
    h("div", { class: "pay-sum__cell" },
      h("span", { class: "pay-sum__label" }, "Recebido"),
      h("strong", { class: "tnum pay-sum__in" }, chf(recebido))),
    h("div", { class: "pay-sum__cell" },
      h("span", { class: "pay-sum__label" }, "Por receber"),
      h("strong", { class: "tnum " + (falta > 0 ? "pay-sum__due" : "") }, chf(falta))));

  const lista = h("div", { class: "pay-list" }, pagamentos.map((p) =>
    h("div", { class: "pay-row" },
      h("span", { class: "tnum pay-row__amt" }, chf(p.amount_cents)),
      h("span", { class: "pay-row__meta" },
        (METODO_PAGAMENTO_LABEL[p.method] || p.method) +
        (p.paid_on ? " · " + fmtDataPt(p.paid_on) : "")),
      h("button", { class: "icon-btn", title: "Remover pagamento",
        "aria-label": "Remover pagamento de " + chf(p.amount_cents),
        onclick: async () => {
          try { await jdel(`/api/faturas/${f.id}/pagamentos/${p.id}`); toast("Pagamento removido."); recarregar(); }
          catch (e) { toast(e.message, "err"); }
        } }, icon("x")))));

  if (fechada || falta <= 0) {
    return h("div", { class: "pay-box" }, resumo, pagamentos.length ? lista : null);
  }

  const valor = h("input", { class: "inp tnum", type: "text", inputmode: "decimal",
    value: (falta / 100).toFixed(2), "aria-label": "Valor recebido" });
  const metodo = h("select", { class: "inp", "aria-label": "Método de pagamento" },
    Object.entries(METODO_PAGAMENTO_LABEL).map(([id, nome]) => h("option", { value: id }, nome)));
  const btn = h("button", { class: "btn btn--primary", onclick: async () => {
    btn.disabled = true;
    try {
      await jpost(`/api/faturas/${f.id}/pagamentos`, { valor: valor.value, metodo: metodo.value });
      toast("Pagamento registado.");
      recarregar();
    } catch (e) { toast(e.message, "err"); btn.disabled = false; }
  } }, "Registar");

  return h("div", { class: "pay-box" }, resumo, pagamentos.length ? lista : null,
    h("div", { class: "pay-form" }, valor, metodo, btn));
}

async function openFatura(id) {
  Drawer.open(h("div", { class: "drawer-body" }, h("div", { class: "skel", style: "height:160px" })));
  let f;
  try { f = await api(`/api/faturas/${id}`); }
  catch (e) { toast(e.message, "err"); Drawer.close(); return; }
  const foot = h("div", { class: "drawer-foot" });
  const run = async (fn) => { try { await fn(); toast("Feito."); Drawer.close(); Router.reload(); } catch (e) { toast(e.message, "err"); } };
  if (f.status === "draft") {
    foot.append(h("button", { class: "btn btn--primary", onclick: () => run(() => jpost(`/api/faturas/${id}/emitir`)) }, "Emitir"));
    foot.append(h("button", { class: "btn btn--danger", onclick: () => run(() => jpost(`/api/faturas/${id}/anular`)) }, "Anular"));
  } else if (f.status === "issued" || f.status === "partial") {
    // "Marcar paga" fecha a conta de uma vez; o registo parcial vive no corpo
    // do drawer, onde está o valor em falta.
    foot.append(h("button", { class: "btn btn--primary", onclick: () => run(() => jpost(`/api/faturas/${id}/pagar`)) }, "Marcar paga"));
    // Uma fatura com dinheiro recebido não se anula — remove-se o pagamento primeiro.
    if (!(f.paid_cents > 0))
      foot.append(h("button", { class: "btn btn--danger", onclick: () => run(() => jpost(`/api/faturas/${id}/anular`)) }, "Anular"));
  }
  if (f.status === "issued" || f.status === "partial" || f.status === "paid") {
    foot.append(h("button", { class: "btn",
      onclick: () => run(() => jpost(`/api/faturas/${id}/reenviar`)) }, icon("send"), "Reenviar PDF"));
  }

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("receipt"), h("h3", {}, f.invoice_number || "Rascunho"),
      h("span", { style: "flex:1" }), h("button", { class: "icon-btn", onclick: () => Drawer.close() }, icon("x"))),
    h("div", { class: "drawer-body" },
      invoiceBadge(f.status, f.due_date),
      h("dl", { class: "dl", style: "margin:14px 0" },
        h("dt", {}, "Cliente"), h("dd", {}, f.customer_name_snapshot || "—"),
        h("dt", {}, "Emitida"), h("dd", {}, f.issue_date ? fmtDataPt(f.issue_date) : "—"),
        h("dt", {}, "Vencimento"), h("dd", {}, f.due_date ? fmtDataPt(f.due_date) : "—")),
      h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" },
        h("thead", {}, h("tr", {}, h("th", {}, "Descrição"), h("th", { class: "num" }, "Qtd"), h("th", { class: "num" }, "Preço"), h("th", { class: "num" }, "Total"))),
        h("tbody", {}, (f.lines || []).map((l) => h("tr", {},
          h("td", {}, l.description), h("td", { class: "num tnum" }, String(l.quantity)),
          h("td", { class: "num tnum" }, chf(l.unit_price_cents)), h("td", { class: "num tnum" }, chf(l.line_total_cents))))))),
      h("dl", { class: "dl", style: "margin-top:14px" },
        h("dt", {}, "Subtotal"), h("dd", { class: "tnum" }, chf(f.subtotal_cents)),
        f.discount_cents ? h("dt", {}, "Desconto") : null,
        f.discount_cents ? h("dd", { class: "tnum" }, "− " + chf(f.discount_cents)) : null,
        h("dt", {}, f.tax_rate_bps ? `IVA (${(f.tax_rate_bps / 100).toFixed(2)}%)` : "IVA"),
        h("dd", { class: "tnum" }, f.tax_rate_bps ? chf(f.tax_cents) : "—"),
        h("dt", { style: "font-weight:600;color:var(--text)" }, "Total"),
        h("dd", { class: "tnum", style: "font-weight:700" }, chf(f.total_cents))),
      f.status === "draft" ? null
        : blocoPagamentos(f, () => { Drawer.close(); Router.reload(); openFatura(id); })),
    foot));
}

/* ===================================================================
   VIEW: RESULTADOS (P3) — impacto económico do BMS.
   Estratégico ("o sistema está a produzir valor?"), nunca operacional —
   isso é o Attention Center em Hoje. Cada número aqui vem de
   GET /api/resultados, que só agrega dados reais (ver reports/results.py).
   Sem lib de gráficos: barras simples com CSS (.res-bar-*).
   =================================================================== */
const RESULTADOS_PERIODOS = [["7d", "7 dias"], ["30d", "30 dias"], ["90d", "90 dias"], ["ano", "Este ano"]];
let resultadosPeriodo = "30d";

function pctLabel(v) {
  return v == null ? "Sem dados suficientes" : String(v).replace(".", ",") + "%";
}

function resBar(label, valueText, amount, max) {
  const pct = max > 0 && amount > 0 ? Math.max(2, Math.round((amount / max) * 100)) : 0;
  return h("div", { class: "res-bar-row" },
    h("div", { class: "res-bar-label" }, label),
    h("div", { class: "res-bar-track" }, h("div", { class: "res-bar-fill", style: `width:${pct}%` })),
    h("div", { class: "res-bar-value tnum" }, valueText));
}

function resDelta(delta, unidade = "%") {
  if (delta == null) return "—";
  const up = delta >= 0;
  return h("span", { class: "res-delta " + (up ? "res-delta--up" : "res-delta--down") },
    (up ? "▲ " : "▼ ") + Math.abs(delta).toFixed(1).replace(".", ",") + unidade);
}

const RESULTADOS_DETALHE_LABEL = {
  marcacoes_whatsapp_bot: "Marcações via WhatsApp Bot",
  marcacoes_rebooking: "Marcações via rebooking automático",
  reminders_enviados: "Reminders 24h enviados",
  cancelamentos_via_reminder: "Cancelamentos via reminder",
  seguimentos_rebooking_enviados: "Seguimentos de rebooking enviados",
  agradecimentos_pos_atendimento: "Agradecimentos pós-atendimento",
  pedidos_feedback: "Pedidos de feedback",
  pdfs_fatura_enviados: "PDFs de fatura enviados",
};

async function viewResultados(mount) {
  setTitle("Resultados", "Impacto económico do BMS");
  const seg = h("div", { class: "seg", role: "tablist", "aria-label": "Período" },
    RESULTADOS_PERIODOS.map(([p, label]) =>
      h("button", { class: resultadosPeriodo === p ? "is-active" : "", role: "tab",
        "aria-selected": String(resultadosPeriodo === p),
        onclick: () => { resultadosPeriodo = p; Router.reload(); } }, label)));
  mount.append(seg, skeletonCard());

  let d;
  try { d = await api(`/api/resultados?periodo=${resultadosPeriodo}`); }
  catch (e) { mount.innerHTML = ""; mount.append(seg, emptyState("Não foi possível carregar: " + e.message)); return; }
  mount.lastChild.remove();

  const b = d.bookings, r = d.revenue, c = d.customers, ns = d.no_show, ca = d.cancellations,
        rem = d.reminders, fb = d.feedback, rb = d.rebooking, ts = d.time_saved, cmp = d.comparacao;

  // 1 — 5 KPIs principais
  mount.append(h("div", { class: "eyebrow", style: "margin-top:20px" }, "Visão geral"));
  mount.append(h("div", { class: "metrics metrics--5" },
    metric(b.bms, "Marcações via BMS", true),
    metric(chf(r.bms_cents), "Receita atribuída ao BMS", true),
    metric(ns.rate_pct == null ? "Sem dados" : pctLabel(ns.rate_pct), "No-show rate"),
    metric(c.recorrentes, "Clientes recorrentes"),
    metric(fmtMin(ts.minutos_estimados), "Tempo poupado (estim.)")));
  mount.append(h("div", { class: "res-note" },
    `Estimativa baseada em ${ts.minutos_por_acao} min por interação automatizada.`));
  if (cmp) {
    mount.append(h("div", { class: "res-note" },
      "vs. período anterior — Marcações BMS ", resDelta(cmp.marcacoes_bms.delta_pct),
      " · Receita paga ", resDelta(cmp.receita_paga_cents.delta_pct),
      " · Receita BMS ", resDelta(cmp.receita_bms_cents.delta_pct),
      " · No-show rate ", resDelta(cmp.no_show_rate_pct.delta_pp, "pp")));
  }

  // 2 — Receita
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Receita"));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(4,1fr)" },
    metric(chf(r.whatsapp_bot_cents), "WhatsApp Bot"),
    metric(chf(r.rebooking_followup_cents), "Rebooking automático"),
    metric(chf(r.dashboard_cents), "Dashboard (manual)"),
    metric(chf(r.total_paid_cents), "Total pago", true)));
  mount.append(h("div", { class: "res-note" },
    `${r.faturas_pagas} faturas pagas · ticket médio ${chf(r.ticket_medio_cents)}.`));
  if (r.por_servico.length) {
    const maxServ = Math.max(...r.por_servico.map((s) => s.total_cents));
    const card = h("div", { class: "card card--pad", style: "margin-top:10px" });
    r.por_servico.slice(0, 8).forEach((s) => card.append(resBar(s.servico, chf(s.total_cents), s.total_cents, maxServ)));
    mount.append(card);
  }

  // 3 — Marcações por origem
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Marcações por origem"));
  const maxOrigem = Math.max(b.whatsapp_bot, b.rebooking_followup, b.dashboard, b.unknown, 1);
  mount.append(h("div", { class: "card card--pad" },
    resBar("WhatsApp Bot", String(b.whatsapp_bot), b.whatsapp_bot, maxOrigem),
    resBar("Rebooking automático", String(b.rebooking_followup), b.rebooking_followup, maxOrigem),
    resBar("Dashboard (manual)", String(b.dashboard), b.dashboard, maxOrigem),
    resBar("Desconhecida", String(b.unknown), b.unknown, maxOrigem)));
  mount.append(h("div", { class: "res-note" },
    `${b.total} marcações criadas no período · ${b.bms} via BMS (WhatsApp Bot + rebooking automático).`));

  // 4 — Clientes
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Clientes"));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(4,1fr)" },
    metric(c.novos, "Novos"),
    metric(c.atendidos, "Atendidos"),
    metric(c.recorrentes, "Recorrentes"),
    metric(c.taxa_recorrencia_pct == null ? "Sem dados" : pctLabel(c.taxa_recorrencia_pct), "Taxa de recorrência")));
  mount.append(h("div", { class: "res-note" },
    "\"Recorrente\" = pelo menos 2 marcações concluídas no histórico (mesma definição usada em Clientes)."));

  // 5 — No-show e cancelamentos (métricas SEPARADAS, nunca conflar)
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "No-show e cancelamentos"));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(3,1fr)" },
    metric(ns.no_shows, "Não compareceu"),
    metric(ns.elegiveis, "Marcações elegíveis"),
    metric(ns.rate_pct == null ? "Sem dados" : pctLabel(ns.rate_pct), "Taxa de no-show")));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(2,1fr);margin-top:10px" },
    metric(ca.cancelamentos, "Cancelamentos"),
    metric(ca.rate_pct == null ? "Sem dados" : pctLabel(ca.rate_pct), "Taxa de cancelamento")));

  // 6 — Reminder 24h
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Reminder 24h"));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(4,1fr)" },
    metric(rem.enviados, "Enviados"),
    metric(rem.confirmacoes, "Confirmações"),
    metric(rem.reagendamentos_iniciados, "Reagendamentos iniciados"),
    metric(rem.cancelamentos, "Cancelamentos")));
  mount.append(h("div", { class: "res-note" },
    "\"Iniciados\" é o clique em reagendar — não prova que o reagendamento foi concluído. Nenhum destes números implica que o reminder \"evitou\" um no-show."));

  // 7 — Rebooking automático
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Rebooking automático"));
  mount.append(h("div", { class: "metrics metrics--5" },
    metric(rb.seguimentos_enviados, "Seguimentos enviados"),
    metric(rb.mais_tarde, "Mais tarde"),
    metric(rb.marcacoes_criadas, "Marcações criadas"),
    metric(rb.conversao_pct == null ? "Sem dados" : pctLabel(rb.conversao_pct), "Conversão"),
    metric(chf(rb.receita_atribuida_cents), "Receita atribuída", true)));
  mount.append(h("div", { class: "res-note" },
    "Conversão = marcações criadas via rebooking / seguimentos enviados no mesmo período (proporção agregada, não um match causal por cliente)."));

  // 8 — Feedback
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Feedback"));
  mount.append(h("div", { class: "metrics", style: "grid-template-columns:repeat(3,1fr)" },
    metric(fb.pedidos, "Pedidos"),
    metric(fb.recebidos, "Recebidos"),
    metric(fb.taxa_resposta_pct == null ? "Sem dados" : pctLabel(fb.taxa_resposta_pct), "Taxa de resposta")));

  // 9 — Funil de automação / tempo poupado
  mount.append(h("div", { class: "eyebrow", style: "margin-top:28px" }, "Ações automatizadas (tempo poupado)"));
  const detEntries = Object.entries(ts.detalhe);
  const maxDet = Math.max(...detEntries.map(([, v]) => v), 1);
  const detCard = h("div", { class: "card card--pad" });
  detEntries.forEach(([k, v]) => detCard.append(resBar(RESULTADOS_DETALHE_LABEL[k] || k, String(v), v, maxDet)));
  mount.append(detCard);
  mount.append(h("div", { class: "res-note" },
    `${ts.acoes_automatizadas} ações automatizadas × ${ts.minutos_por_acao} min ≈ ${fmtMin(ts.minutos_estimados)} estimados — `,
    "estimativa, não medição real. Não inclui reagendamentos/cancelamentos feitos pelo próprio cliente (sem marcador de origem hoje)."));

  // 10 — âmbito desta versão
  mount.append(h("div", { class: "res-note", style: "margin-top:24px" },
    "Ocupação da agenda não é mostrada nesta versão: o cálculo correto exige cruzar horário de funcionamento, exceções e durações reais — um número aproximado arriscaria enganar."));
}

/* ===================================================================
   VIEW: DEFINIÇÕES  (faturação)
   =================================================================== */
async function viewDefinicoes(mount) {
  setTitle("Definições", "Faturação");
  mount.append(skeletonCard());
  let cfg;
  try { cfg = await api("/api/definicoes/faturacao"); }
  catch (e) { toast(e.message, "err"); return; }
  mount.lastChild.remove();
  const f = (name, k, val, attrs = {}) => h("div", { class: "field" }, h("label", {}, name),
    h("input", Object.assign({ class: "inp", value: val ?? "", "data-k": k }, attrs)));
  const form = h("div", { class: "card card--pad", style: "max-width:520px" },
    h("div", { class: "eyebrow", style: "margin-top:0" }, "Dados do negócio (aparecem na fatura)"),
    f("Nome legal", "legal_name", cfg.legal_name),
    f("Morada", "address", cfg.address),
    h("div", { style: "display:flex;gap:12px" },
      f("Código postal", "postal_code", cfg.postal_code, { style: "max-width:140px" }),
      f("Localidade", "city", cfg.city)),
    f("Email", "email", cfg.email, { type: "email" }),
    f("Telefone", "phone", cfg.phone),
    f("IBAN", "iban", cfg.iban, { placeholder: "só se quiseres que apareça na fatura" }),
    h("div", { class: "eyebrow" }, "IVA / MWST"),
    h("label", { class: "field", style: "display:flex;gap:8px;align-items:center" },
      h("input", { type: "checkbox", "data-k": "vat_enabled", checked: cfg.vat_enabled || undefined }),
      h("span", {}, "Cobrar IVA nas faturas")),
    f("Taxa de IVA (basis points, ex.: 810 = 8,10%)", "vat_rate_bps", cfg.vat_rate_bps || "", { type: "number", min: 0 }),
    f("Número de IVA (UID)", "vat_number", cfg.vat_number),
    h("div", { class: "eyebrow" }, "Faturação"),
    f("Prefixo do número", "invoice_prefix", cfg.invoice_prefix, { placeholder: "vazio → 2026-0001" }),
    f("Prazo de pagamento (dias)", "payment_terms_days", cfg.payment_terms_days ?? 30, { type: "number", min: 0 }),
    f("Rodapé da fatura", "invoice_footer", cfg.invoice_footer),
    h("button", { class: "btn btn--primary", style: "margin-top:8px", onclick: async () => {
      const patch = {};
      $$("[data-k]", form).forEach((i) => {
        if (i.type === "checkbox") patch[i.dataset.k] = i.checked;
        else if (i.value !== "") patch[i.dataset.k] = i.type === "number" ? Number(i.value) : i.value;
        else patch[i.dataset.k] = null;
      });
      try { await jput("/api/definicoes/faturacao", patch); toast("Definições guardadas."); }
      catch (e) { toast(e.message, "err"); }
    } }, "Guardar"));
  mount.append(form);
  mount.append(h("p", { class: "empty", style: "text-align:left;padding:16px 2px;max-width:520px" },
    "Nada é preenchido automaticamente — IBAN, número de IVA e taxa só aparecem na fatura depois de os introduzires aqui."));
}

/* ===================================================================
   VIEW: CAMPANHAS (P5) — reativação de clientes por WhatsApp.
   Segmentação em tempo real (POST /api/campanhas/segmentar, nunca persiste)
   -> rascunho -> agendar/enviar agora (snapshot no backend) -> executor
   processa em lote (ver campaigns/engine.py) -> clique -> fluxo de marcação
   normal -> conversão. "Enviar agora" usa sempre a modal premium (§11 do
   patch) — nunca window.confirm.
   =================================================================== */
const CAMPANHA_STATUS_LABEL = {
  draft: "Rascunho", scheduled: "Agendada", running: "A decorrer",
  completed: "Concluída", cancelled: "Cancelada",
};
const CAMPANHA_STATUS_BADGE = {
  draft: "", scheduled: "badge--info", running: "badge--warning",
  completed: "badge--success", cancelled: "badge--danger",
};
function campanhaBadge(status) {
  return h("span", { class: "badge " + (CAMPANHA_STATUS_BADGE[status] || "") },
    CAMPANHA_STATUS_LABEL[status] || status);
}
const CAMPANHA_RECIPIENT_LABEL = {
  pending: ["Pendente", ""], sent: ["Enviada", "badge--info"], failed: ["Falhou", "badge--danger"],
  clicked: ["Clicou", "badge--warning"], converted: ["Marcou", "badge--success"], skipped: ["Ignorado", ""],
};
function campanhaRecipientBadge(status) {
  const [label, cls] = CAMPANHA_RECIPIENT_LABEL[status] || [status, ""];
  return h("span", { class: "badge " + cls }, label);
}
function segmentoResumo(filtros) {
  filtros = filtros || {};
  const partes = [];
  if (filtros.no_visit_days) partes.push(`Sem visita há ${filtros.no_visit_days}d`);
  if (filtros.service_id) partes.push("Serviço anterior");
  if (filtros.no_future_booking) partes.push("Sem marcação futura");
  if (filtros.recurring) partes.push("Recorrentes");
  if (filtros.last_visit_from || filtros.last_visit_to) partes.push("Última visita em intervalo");
  return partes.length ? partes.join(" · ") : "Todos os clientes elegíveis";
}

async function viewCampanhas(mount) {
  setTitle("Campanhas", "Reative clientes e preencha a agenda.");
  const btnNova = h("button", { class: "btn btn--primary", onclick: () => openCampanhaBuilder() },
    icon("megaphone"), "Nova campanha");
  mount.append(h("div", { style: "display:flex;justify-content:flex-end;margin-bottom:16px" }, btnNova));
  mount.append(skeletonCard());
  let d;
  try { d = await api("/api/campanhas"); }
  catch (e) { mount.lastChild.remove(); mount.append(emptyState("Não foi possível carregar: " + e.message)); return; }
  mount.lastChild.remove();
  const lista = d.campanhas || [];

  const rascunhos = lista.filter((c) => c.status === "draft").length;
  const agendadas = lista.filter((c) => c.status === "scheduled").length;
  const enviadas = lista.filter((c) => c.status === "running" || c.status === "completed").length;
  const conversoes = lista.reduce((s, c) => s + (c.recipients_converted || 0), 0);
  mount.append(h("div", { class: "metrics metrics--5" },
    metric(rascunhos, "Rascunhos"), metric(agendadas, "Agendadas"),
    metric(enviadas, "Enviadas"), metric(conversoes, "Conversões", true)));

  if (!lista.length) {
    mount.append(h("div", { style: "margin-top:20px" },
      emptyState("Ainda não há campanhas — crie a primeira para reativar clientes sem marcação recente.")));
    return;
  }

  const wrap = h("div", { style: "margin-top:20px" });
  lista.forEach((c) => wrap.append(
    h("div", { class: "campaign-card", onclick: () => openCampanha(c.id) },
      h("div", {},
        h("div", { class: "cc-name" }, c.name),
        h("div", { class: "cc-meta" }, segmentoResumo(c.segment_json),
          c.scheduled_at ? " · " + fmtDataHoraPt(c.scheduled_at) : ""),
        h("div", { style: "margin-top:8px" }, campanhaBadge(c.status))),
      h("div", { class: "cc-stats" },
        h("div", {}, h("div", { class: "cc-stat-val tnum" }, String(c.recipients_total)),
          h("div", { class: "cc-stat-lbl" }, "Destinatários")),
        h("div", {}, h("div", { class: "cc-stat-val tnum" }, String(c.recipients_sent)),
          h("div", { class: "cc-stat-lbl" }, "Enviadas")),
        h("div", {}, h("div", { class: "cc-stat-val tnum" }, String(c.recipients_clicked)),
          h("div", { class: "cc-stat-lbl" }, "Cliques")),
        h("div", {}, h("div", { class: "cc-stat-val tnum" }, String(c.recipients_converted)),
          h("div", { class: "cc-stat-lbl" }, "Marcações"))))));
  mount.append(wrap);
}

/* ---------- detalhe de UMA campanha ---------- */
async function openCampanha(id) {
  Drawer.open(h("div", { class: "drawer-body" }, h("div", { class: "skel", style: "height:160px" })));
  let c, dest;
  try {
    c = await api(`/api/campanhas/${id}`);
    dest = (await api(`/api/campanhas/${id}/destinatarios`)).destinatarios || [];
  } catch (e) { toast(e.message, "err"); Drawer.close(); return; }

  const conversao = c.recipients_sent ? Math.round((c.recipients_converted / c.recipients_sent) * 1000) / 10 : null;

  const head = h("div", { class: "drawer-head" },
    icon("megaphone"), h("h3", {}, c.name),
    h("span", { style: "flex:1" }),
    h("button", { class: "icon-btn", onclick: () => Drawer.close(), "aria-label": "Fechar" }, icon("x")));

  const body = h("div", { class: "drawer-body" },
    h("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap" },
      campanhaBadge(c.status),
      h("span", { style: "color:var(--text-3);font-size:12.5px" }, segmentoResumo(c.segment_json))),
    h("div", { class: "metrics" },
      metric(c.recipients_sent, "Enviadas"), metric(c.recipients_failed, "Falhadas"),
      metric(c.recipients_clicked, "Cliques"), metric(c.recipients_converted, "Marcações", true)),
    conversao != null
      ? h("div", { class: "res-note" }, `Taxa de conversão: ${conversao}% (marcações / enviadas).`)
      : null,
    h("div", { class: "eyebrow", style: "margin-top:20px" }, "Pré-visualização WhatsApp"),
    h("div", { class: "wa-preview" },
      h("div", { class: "wa-preview-bubble" }, c.preview.texto),
      h("div", { class: "wa-preview-btn" }, c.preview.botao)),
    h("div", { class: "eyebrow", style: "margin-top:20px" }, `Destinatários (${dest.length})`),
    dest.length
      ? h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" },
          h("thead", {}, h("tr", {}, h("th", {}, "Cliente"), h("th", {}, "Telefone"),
            h("th", {}, "Estado"), h("th", {}, "Enviado"))),
          h("tbody", {}, dest.slice(0, 300).map((r) => h("tr", {},
            h("td", {}, r.name || "Cliente"), h("td", { class: "tnum" }, r.phone),
            h("td", {}, campanhaRecipientBadge(r.status)),
            h("td", {}, r.sent_at ? fmtDataHoraPt(r.sent_at) : "—"))))))
      : emptyState("Sem destinatários — esta campanha ainda não foi agendada nem enviada."));

  const foot = h("div", { class: "drawer-foot" });
  if (c.status === "draft") {
    foot.append(h("button", { class: "btn", onclick: () => openCampanhaBuilder(c) }, "Editar"));
    foot.append(h("button", { class: "btn", onclick: () => openAgendarCampanha(c) }, icon("clock"), "Agendar"));
    foot.append(h("button", { class: "btn btn--primary", onclick: () => enviarCampanhaAgora(c) }, icon("send"), "Enviar agora"));
    foot.append(h("button", { class: "btn btn--danger", onclick: () => apagarCampanhaPrompt(c) }, "Apagar"));
  } else if (c.status === "scheduled") {
    foot.append(h("button", { class: "btn btn--primary", onclick: () => enviarCampanhaAgora(c) }, icon("send"), "Enviar agora"));
    foot.append(h("button", { class: "btn btn--danger", onclick: () => cancelarCampanhaPrompt(c) }, "Cancelar"));
  } else if (c.status === "running") {
    foot.append(h("button", { class: "btn btn--danger", onclick: () => cancelarCampanhaPrompt(c) }, "Cancelar"));
  }

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" }, head, body, foot));
}

async function apagarCampanhaPrompt(c) {
  if (!confirm(`Apagar o rascunho "${c.name}"? Esta ação não pode ser desfeita.`)) return;
  try {
    await api(`/api/campanhas/${c.id}`, { method: "DELETE" });
    toast("Rascunho apagado."); Drawer.close(); Router.reload();
  } catch (e) { toast(e.message, "err"); }
}

async function cancelarCampanhaPrompt(c) {
  if (!confirm(`Cancelar a campanha "${c.name}"? Mensagens já enviadas não são desfeitas — só os `
    + "destinatários ainda pendentes deixam de receber.")) return;
  try {
    await jpost(`/api/campanhas/${c.id}/cancelar`, {});
    toast("Campanha cancelada."); Drawer.close(); Router.reload();
  } catch (e) { toast(e.message, "err"); }
}

/* ---------- "Agendar" — data/hora, modal simples ---------- */
function openAgendarCampanha(c) {
  const iData = h("input", { class: "inp", type: "date", min: hojeYmdNegocio() });
  const iHora = h("input", { class: "inp", type: "time", value: "09:00" });
  const btnCancelar = h("button", { class: "btn", onclick: () => Modal.close() }, "Cancelar");
  const btnAgendar = h("button", { class: "btn btn--primary" }, icon("clock"), "Agendar campanha");
  btnAgendar.addEventListener("click", async () => {
    if (!iData.value || !HORA_RE.test(iHora.value)) { toast("Data e hora são obrigatórias.", "err"); return; }
    btnAgendar.disabled = true;
    try {
      await jpost(`/api/campanhas/${c.id}/agendar`, { data: iData.value, hora: iHora.value });
      toast("Campanha agendada.");
      Modal.close(); Drawer.close(); Router.reload();
    } catch (e) { btnAgendar.disabled = false; toast(e.message, "err"); }
  });
  const titleId = "campanha-agendar-" + c.id;
  const panel = h("div", { class: "modal" },
    h("button", { class: "icon-btn modal-close", onclick: () => Modal.close(), "aria-label": "Fechar" }, icon("x")),
    h("div", { class: "resched-icon" }, icon("clock")),
    h("h3", { id: titleId, class: "resched-title" }, "Agendar campanha"),
    h("p", { class: "resched-copy" }, `"${c.name}" será enviada automaticamente na data/hora escolhida.`),
    h("div", { style: "display:flex;gap:12px;margin-bottom:20px" },
      h("div", { class: "field", style: "flex:1;margin:0" }, h("label", {}, "Data"), iData),
      h("div", { class: "field", style: "flex:1;margin:0" }, h("label", {}, "Hora"), iHora)),
    h("div", { class: "resched-actions" }, btnCancelar, btnAgendar));
  Modal.open(panel, { labelledby: titleId });
}

/* ---------- "Enviar agora" — SEMPRE a modal premium, nunca window.confirm ---------- */
async function enviarCampanhaAgora(c) {
  let preview;
  try { preview = await jpost("/api/campanhas/segmentar", { filtros: c.segment_json || {} }); }
  catch (e) { toast(e.message, "err"); return; }
  const elegiveis = c.status === "draft" ? preview.elegiveis : c.recipients_total;

  const btnCancelar = h("button", { class: "btn", onclick: () => Modal.close() }, "Cancelar");
  const btnEnviar = h("button", { class: "btn btn--primary" }, icon("send"), "Enviar campanha");
  const setEnviando = (on) => {
    btnEnviar.disabled = on; btnCancelar.disabled = on; Modal.setClosable(!on);
    btnEnviar.innerHTML = ""; btnEnviar.append(icon("send"), on ? "A enviar…" : "Enviar campanha");
  };
  btnEnviar.addEventListener("click", async () => {
    if (btnEnviar.disabled) return;
    setEnviando(true);
    try {
      await jpost(`/api/campanhas/${c.id}/enviar-agora`, {});
      toast("Campanha a ser enviada.");
      Modal.close(); Drawer.close(); Router.reload();
    } catch (e) {
      setEnviando(false);
      toast(e.message || "Não foi possível enviar a campanha.", "err");
    }
  });
  const titleId = "campanha-enviar-" + c.id;
  const panel = h("div", { class: "modal" },
    h("button", { class: "icon-btn modal-close", onclick: () => Modal.close(), "aria-label": "Fechar" }, icon("x")),
    h("div", { class: "resched-icon" }, icon("megaphone")),
    h("h3", { id: titleId, class: "resched-title" }, "Enviar campanha?"),
    h("p", { class: "resched-copy" },
      `${elegiveis} clientes elegíveis · Template: Reativação de clientes.`),
    h("p", { class: "resched-copy" },
      "Este envio utiliza mensagens template do WhatsApp — fora da janela de 24h de atendimento, "
      + "é o único tipo de mensagem permitido para um contacto proativo."),
    h("div", { class: "resched-actions" }, btnCancelar, btnEnviar));
  Modal.open(panel, { labelledby: titleId });
}

/* ---------- "Nova campanha" / "Editar" — segmentação em tempo real ---------- */
function openCampanhaBuilder(existing) {
  const isEdit = !!existing;
  let filtros = isEdit ? { ...(existing.segment_json || {}) } : {};
  let campaignId = isEdit ? existing.id : null;

  const iNome = h("input", { class: "inp", value: isEdit ? existing.name : "",
    placeholder: "Ex.: Reativação setembro" });

  const selVisita = h("select", { class: "inp" },
    h("option", { value: "" }, "— Nenhum —"),
    [30, 60, 90, 180].map((n) =>
      h("option", { value: n, selected: filtros.no_visit_days === n || undefined }, `${n} dias`)));

  const selServico = h("select", { class: "inp" }, h("option", { value: "" }, "— Nenhum —"));
  getServicos().then((servicos) => {
    servicos.filter((s) => s.ativo).forEach((s) => selServico.append(
      h("option", { value: s.id, selected: filtros.service_id === s.id || undefined }, s.nome_pt)));
  }).catch(() => {});

  const chkFutura = h("input", { type: "checkbox", checked: !!filtros.no_future_booking || undefined });
  const chkRecorrente = h("input", { type: "checkbox", checked: !!filtros.recurring || undefined });

  const contadorN = h("span", { class: "seg-counter-n" }, "…");
  const contadorExcl = h("span", { class: "seg-counter-excl" }, "");
  const previewBubble = h("div", { class: "wa-preview-bubble" }, "…");
  const previewBtn = h("div", { class: "wa-preview-btn" }, "…");

  const lerFiltros = () => {
    const f = {};
    if (selVisita.value) f.no_visit_days = Number(selVisita.value);
    if (selServico.value) f.service_id = selServico.value;
    if (chkFutura.checked) f.no_future_booking = true;
    if (chkRecorrente.checked) f.recurring = true;
    return f;
  };

  let debounceTimer = null;
  const atualizarContador = async () => {
    filtros = lerFiltros();
    try {
      const r = await jpost("/api/campanhas/segmentar", { filtros });
      contadorN.textContent = `${r.elegiveis} clientes elegíveis`;
      contadorExcl.textContent = r.excluidos ? `· ${r.excluidos} excluídos` : "";
      previewBubble.textContent = r.preview.texto;
      previewBtn.textContent = r.preview.botao;
    } catch (e) { contadorN.textContent = "—"; }
  };
  const agendarContador = () => { clearTimeout(debounceTimer); debounceTimer = setTimeout(atualizarContador, 150); };
  [selVisita, selServico].forEach((el) => el.addEventListener("change", agendarContador));
  [chkFutura, chkRecorrente].forEach((el) => el.addEventListener("change", agendarContador));
  atualizarContador();

  const body = h("div", { class: "drawer-body" },
    h("div", { class: "field" }, h("label", {}, "Nome da campanha"), iNome),
    h("div", { class: "eyebrow", style: "margin-top:20px" }, "Público"),
    h("div", { class: "seg-filters" },
      h("div", { class: "field", style: "margin:0" }, h("label", {}, "Sem visita há"), selVisita),
      h("div", { class: "field", style: "margin:0" }, h("label", {}, "Serviço anterior"), selServico),
      h("label", { class: "seg-check" }, chkFutura, "Sem marcação futura"),
      h("label", { class: "seg-check" }, chkRecorrente, "Cliente recorrente (2+ visitas)")),
    h("div", { class: "seg-counter" }, contadorN, contadorExcl),
    h("div", { class: "eyebrow" }, "Pré-visualização WhatsApp"),
    h("div", { class: "wa-preview" }, previewBubble, previewBtn),
    h("div", { class: "res-note" },
      "Template: Reativação de clientes. O idioma da mensagem é escolhido automaticamente pelo idioma do cliente."));

  const btnGuardar = h("button", { class: "btn" }, "Guardar rascunho");
  const foot = h("div", { class: "drawer-foot" }, btnGuardar);
  if (isEdit) {
    const btnAgendar = h("button", { class: "btn" }, icon("clock"), "Agendar");
    const btnEnviar = h("button", { class: "btn btn--primary" }, icon("send"), "Enviar agora");
    btnAgendar.addEventListener("click", () => openAgendarCampanha({ id: campaignId, name: iNome.value }));
    btnEnviar.addEventListener("click", () =>
      enviarCampanhaAgora({ id: campaignId, name: iNome.value, status: "draft", segment_json: filtros }));
    foot.append(btnAgendar, btnEnviar);
  }

  btnGuardar.addEventListener("click", async () => {
    const nome = iNome.value.trim();
    if (!nome) { toast("Escreva um nome para a campanha.", "err"); return; }
    filtros = lerFiltros();
    btnGuardar.disabled = true;
    try {
      const camp = campaignId
        ? await jpatch(`/api/campanhas/${campaignId}`, { name: nome, filtros })
        : await jpost("/api/campanhas", { name: nome, filtros });
      campaignId = camp.id;
      toast("Rascunho guardado.");
      openCampanha(campaignId);   // reabre já como detalhe, com Agendar/Enviar/Apagar
      Router.reload();
    } catch (e) { toast(e.message, "err"); }
    finally { btnGuardar.disabled = false; }
  });

  Drawer.open(h("div", { style: "display:flex;flex-direction:column;height:100%" },
    h("div", { class: "drawer-head" }, icon("megaphone"),
      h("h3", {}, isEdit ? "Editar campanha" : "Nova campanha"),
      h("span", { style: "flex:1" }),
      h("button", { class: "icon-btn", onclick: () => Drawer.close(), "aria-label": "Fechar" }, icon("x"))),
    body, foot));
}

/* ===================================================================
   CONVERSAS — o fio de mensagens de cada cliente.

   O texto das mensagens passou a ser guardado (ver messaging/conversas.py
   e migração 25); esta é a vista que o lê. É indexada por TELEFONE e não
   por cliente: uma conversa existe desde a primeira mensagem, e a ficha
   de cliente só nasce na primeira marcação — quem pede ajuda antes de
   marcar, que é o caso que isto serve, não tem ficha nenhuma.

   Nada aqui é invenção: lista de fios à esquerda, mensagens recebidas de
   um lado e enviadas do outro, separador por dia, caixa de resposta em
   baixo. A única peça que não existe em nenhuma outra vista é o aviso da
   janela de 24h (convTextoJanela), SEMPRE visível antes de se escrever:
   a resposta livre pelo WhatsApp só é permitida nas 24h seguintes à
   última mensagem da cliente, e sem o prazo à vista escreve-se um texto
   longo para levar um 409 no fim, sem se entender porquê.
   =================================================================== */
const _convDiaCurto = new Intl.DateTimeFormat("pt-PT", {
  timeZone: TZ_NEGOCIO, day: "2-digit", month: "short" });
const _convDiaLongo = new Intl.DateTimeFormat("pt-PT", {
  timeZone: TZ_NEGOCIO, weekday: "long", day: "2-digit", month: "long" });

// Tudo no relógio do NEGÓCIO (Europe/Zurich), como no resto do painel: a
// hora que ela vê tem de ser a hora do salão, não a do browser.
function convData(iso) { const d = new Date(iso); return isNaN(d) ? "" : _dataNegocio.format(d); }
function convHora(iso) { const d = new Date(iso); return isNaN(d) ? "" : _horaNegocio.format(d); }

function convQuando(iso) {
  const dia = convData(iso);
  if (!dia) return "";
  if (dia === hojeYmdNegocio()) return convHora(iso);
  return _convDiaCurto.format(new Date(iso)).replace(".", "");
}

function convDiaLabel(iso) {
  const dia = convData(iso);
  if (!dia) return "";
  if (dia === hojeYmdNegocio()) return "Hoje";
  if (dia === _dataNegocio.format(new Date(Date.now() - 864e5))) return "Ontem";
  return _convDiaLongo.format(new Date(iso));
}

const convTelefoneLegivel = (t) => "+" + (t || "");

function convTelefoneDoHash() {
  const partes = (location.hash || "").replace(/^#\//, "").split("/");
  return /^\d{8,15}$/.test(partes[1] || "") ? partes[1] : "";
}

async function viewConversas(mount) {
  setTitle("Conversas");
  const alvo = convTelefoneDoHash();
  const painelLista = h("aside", { class: "conv-lista" });
  const painelFio = h("section", { class: "conv-fio" });
  mount.append(h("div", { class: "conv" + (alvo ? " has-fio" : "") }, painelLista, painelFio));

  painelLista.append(h("div", { class: "skel", style: "height:64px;margin:12px" }));
  let d;
  try { d = await api("/api/conversas"); }
  catch (e) { painelLista.innerHTML = ""; painelLista.append(emptyState(e.message)); return; }

  const lista = d.conversas || [];
  const pedidos = lista.filter((c) => c.pedido_humano).length;
  $("#nav-humano").hidden = !pedidos;
  $("#nav-humano").textContent = pedidos;

  const procura = h("input", { class: "inp", placeholder: "Procurar por nome ou número…" });
  const cab = h("div", { class: "conv-lista__cab" }, procura,
    h("div", { class: "conv-lista__cont" },
      lista.length ? `${lista.length} conversa(s)` + (pedidos ? ` · ${pedidos} a pedir ajuda` : "") : "Sem conversas"));
  const fios = h("div", {});
  painelLista.innerHTML = "";
  painelLista.append(cab, fios);

  const desenhar = (visiveis) => {
    fios.innerHTML = "";
    if (!visiveis.length) fios.append(emptyState(lista.length ? "Nenhuma conversa encontrada." : "Ainda não há conversas."));
    visiveis.forEach((c) => fios.append(convItem(c, c.telefone === alvo)));
  };
  desenhar(lista);
  procura.addEventListener("input", () => {
    const q = procura.value.trim().toLowerCase();
    desenhar(lista.filter((c) => ((c.nome || "") + " " + c.telefone).toLowerCase().includes(q)));
  });

  if (!alvo) {
    painelFio.append(h("div", { class: "conv-vazio" }, icon("chat"),
      h("div", {}, lista.length
        ? "Escolhe uma conversa para ver o histórico e responder."
        : "Quando uma cliente escrever ao bot, a conversa aparece aqui.")));
    return;
  }
  await convAbrirFio(painelFio, alvo);
}

function convItem(c, ativa) {
  const nome = c.nome || convTelefoneLegivel(c.telefone);
  const resumo = (c.ultimo_texto || "").replace(/\s+/g, " ").slice(0, 160)
    || "[" + (c.ultimo_tipo || "mensagem") + "]";
  return h("a", {
    class: "conv-item" + (ativa ? " is-ativa" : "") + (c.pedido_humano ? " is-humano" : ""),
    href: "#/conversas/" + c.telefone },
    h("span", { class: "avatar" }, initials(nome)),
    h("div", { class: "conv-item__body" },
      h("div", { class: "conv-item__top" },
        h("span", { class: "conv-item__nome" }, nome),
        h("span", { class: "conv-item__quando" }, convQuando(c.ultima_em))),
      h("div", { class: "conv-item__last" },
        c.ultima_direcao === "enviada" ? h("span", { class: "conv-item__eu" }, "Tu: ") : null,
        resumo),
      c.pedido_humano ? h("span", { class: "badge badge--danger" }, "Pediu para falar contigo") : null));
}

async function convAbrirFio(painel, telefone) {
  painel.innerHTML = "";
  painel.append(h("div", { class: "skel", style: "height:160px;margin:16px" }));
  let d;
  try { d = await api("/api/conversas/" + telefone); }
  catch (e) { painel.innerHTML = ""; painel.append(emptyState(e.message)); return; }
  const msgs = convMensagens(d.mensagens || []);
  painel.innerHTML = "";
  painel.append(convCabecaFio(d), msgs, convCaixaResposta(d));
  // Um fio abre-se no fim, como em qualquer aplicação de mensagens.
  msgs.scrollTop = msgs.scrollHeight;
}

function convCabecaFio(d) {
  const nome = d.nome || convTelefoneLegivel(d.telefone);
  const acoes = h("div", { class: "conv-cab__acoes" });
  if (d.customer_id)
    acoes.append(h("button", { class: "btn btn--sm", onclick: () => openCliente(d.customer_id) },
      icon("user-check"), "Ficha"));
  return h("header", { class: "conv-cab" },
    h("button", { class: "btn btn--subtle btn--sm conv-voltar", "aria-label": "Voltar às conversas",
      onclick: () => { location.hash = "#/conversas"; } }, icon("arrow")),
    h("span", { class: "avatar" }, initials(nome)),
    h("div", { class: "conv-cab__quem" },
      h("div", { class: "conv-cab__nome" }, nome),
      h("div", { class: "conv-cab__tel" },
        convTelefoneLegivel(d.telefone) + (d.idioma ? " · " + String(d.idioma).toUpperCase() : ""))),
    acoes);
}

function convMensagens(msgs) {
  const wrap = h("div", { class: "conv-msgs" });
  let dia = "";
  msgs.forEach((m) => {
    const dm = convData(m.criado_em);
    if (dm && dm !== dia) {
      dia = dm;
      wrap.append(h("div", { class: "conv-dia" }, h("span", {}, convDiaLabel(m.criado_em))));
    }
    wrap.append(convBolha(m));
  });
  if (!msgs.length) wrap.append(emptyState("Sem mensagens neste fio."));
  return wrap;
}

function convBolha(m) {
  const enviada = m.direcao === "enviada";
  // `texto` é o que uma PESSOA lê — num toque num botão é o título que a
  // cliente viu, não o `opt_1`. O id fica no title, para quem precisar de
  // depurar o fluxo sem o mostrar a quem só quer ler a conversa.
  const texto = m.texto || "[" + (m.tipo_rotulo || m.tipo || "mensagem") + "]";
  const etiqueta = m.tipo && m.tipo !== "texto" ? (m.tipo_rotulo || m.tipo) : null;
  return h("div", { class: "conv-msg " + (enviada ? "is-enviada" : "is-recebida") },
    h("div", { class: "conv-bolha", title: m.id_interativo ? "ID: " + m.id_interativo : null },
      h("div", { class: "conv-texto" }, texto),
      h("div", { class: "conv-meta" },
        etiqueta ? h("span", { class: "conv-tipo" }, etiqueta) : null,
        h("span", {}, convHora(m.criado_em)))));
}

// O AVISO DA JANELA DE 24h. A Meta só permite texto livre nas 24h a
// seguir à última mensagem da cliente; depois disso, só um template
// aprovado. Dizer o PRAZO (e não um "sim/não") é o que torna isto
// utilizável: ela decide se responde agora ou se tem de esperar que a
// cliente escreva outra vez.
function convTextoJanela(d) {
  const j = d.janela || {};
  if (j.aberta) {
    const hora = convHora(j.expira_em);
    if (j.minutos_restantes != null && j.minutos_restantes <= 60)
      return `Podes responder durante ${j.minutos_restantes} min — a janela fecha às ${hora}.`;
    const dia = convData(j.expira_em);
    if (dia === hojeYmdNegocio()) return `Podes responder até às ${hora}.`;
    if (dia === _dataNegocio.format(new Date(Date.now() + 864e5)))
      return `Podes responder até amanhã às ${hora}.`;
    return `Podes responder até ${convQuando(j.expira_em)} às ${hora}.`;
  }
  const fechou = "A janela de 24h fechou — só com um template aprovado pela Meta.";
  if (d.demo) return fechou + " (Número de demonstração: o envio fica registado sem sair.)";
  return fechou;
}

function convCaixaResposta(d) {
  const aberta = !!(d.janela || {}).aberta;
  const bloqueado = !aberta && !d.demo;
  const texto = h("textarea", { class: "inp", rows: 2, maxlength: 1000,
    placeholder: bloqueado ? "A janela de 24h está fechada." : "Escrever resposta…",
    disabled: bloqueado });
  const btn = h("button", { class: "btn btn--primary", disabled: bloqueado }, icon("send"), "Enviar");
  const enviar = async () => {
    const t = texto.value.trim();
    if (!t) { toast("Escreva uma mensagem antes de enviar.", "err"); return; }
    btn.disabled = true;
    try {
      const r = await jpost(`/api/conversas/${d.telefone}/mensagem`, { texto: t });
      texto.value = "";
      toast(r.demo ? "Número de demonstração — mensagem registada, sem envio real." : "Mensagem enviada.");
      Router.reload();
    } catch (e) {
      // 409 = a janela fechou entretanto. Recarregar mostra logo o aviso
      // no estado certo, em vez de deixar a caixa a convidar a tentar
      // outra vez o que já não é possível.
      toast(e.message, "err");
      if (e.status === 409) Router.reload();
      else btn.disabled = false;
    }
  };
  btn.addEventListener("click", enviar);
  texto.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); enviar(); }
  });
  return h("div", { class: "conv-resposta" },
    h("div", { class: "conv-janela " + (aberta ? "is-aberta" : "is-fechada") },
      icon(aberta ? "clock" : "alert"), h("span", {}, convTextoJanela(d))),
    h("div", { class: "conv-resposta__linha" }, texto, btn),
    h("div", { class: "conv-resposta__dica" },
      "Sai do número do bot — o teu número pessoal nunca é mostrado à cliente."));
}

/* ===================================================================
   ROUTER
   =================================================================== */
const ROUTES = {
  hoje: viewHoje, agenda: viewAgenda, clientes: viewClientes, conversas: viewConversas,
  servicos: viewServicos, horarios: viewHorarios, faturas: viewFaturas,
  campanhas: viewCampanhas, resultados: viewResultados, definicoes: viewDefinicoes,
};
const Router = {
  current: "hoje",
  reload() { this.render(this.current); },
  render(name) {
    this.current = name;
    const view = $("#view");
    view.innerHTML = "";
    view.classList.toggle("view-narrow", ["definicoes"].includes(name));
    // Agenda precisa de (quase) toda a largura — as outras vistas ficam
    // no teto de leitura confortável (980px) de .view. Ver .view-wide.
    view.classList.toggle("view-wide", ["agenda", "conversas"].includes(name));
    // Só a Agenda é um "workspace" de altura fixa ao viewport (zero scroll
    // da página, ver .main.is-agenda) — Clientes/Faturas/Definições… mantêm
    // o scroll normal da página, exatamente como antes.
    $(".main").classList.toggle("is-agenda", ["agenda"].includes(name));
    // Conversas é o outro "workspace" de altura fixa ao viewport: o scroll
    // é dentro da lista e dentro do fio, nunca da página — a caixa de
    // resposta tem de ficar sempre à vista (ver .main.is-conversas).
    $(".main").classList.toggle("is-conversas", name === "conversas");
    if (!["agenda"].includes(name)) _agendaRelayout = null;
    $$(".nav-item").forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === "#/" + name));
    (ROUTES[name] || viewHoje)(view).catch((e) => { view.innerHTML = ""; view.append(emptyState(e.message)); });
    $("#sidebar").classList.remove("open");
    $("#scrim").classList.remove("open");
  },
};
function setTitle(t, sub = "") { $("#page-title").textContent = t; $("#page-sub").textContent = sub; }

function parseHash() {
  const m = (location.hash || "#/hoje").replace(/^#\//, "").split("/")[0];
  return ROUTES[m] ? m : "hoje";
}
window.addEventListener("hashchange", () => Router.render(parseHash()));

// Resize da janela: só interessa à Agenda (a única vista com altura/largura
// dinâmicas, ver AG_FAIXA/computeAgFaixa). Nunca refaz o pedido à API —
// _agendaRelayout (definido em viewAgenda) só recalcula e redesenha a
// grelha já carregada. Debounce simples: um resize a arrastar a janela
// dispara dezenas de eventos, um redesenho por evento seria desperdício.
let _resizeTimer = null;
window.addEventListener("resize", () => {
  if (!_agendaRelayout) return;
  clearTimeout(_resizeTimer);
  _resizeTimer = setTimeout(_agendaRelayout, 120);
});

/* ---------- boot ---------- */
function initNovoMenu() {
  const wrap = $("#novo-wrap"), btn = $("#novo-btn"), menu = $("#novo-menu");
  const closeMenu = () => { menu.hidden = true; btn.setAttribute("aria-expanded", "false"); };
  const items = [
    { label: "Nova marcação", icon: "calendar", run: () => openCreateAppointment() },
    { label: "Novo cliente", icon: "users", soon: "Funcionalidade pendente de endpoint backend" },
    { label: "Bloquear horário", icon: "clock", soon: "Backend só suporta bloqueio do dia inteiro — em breve" },
    { label: "Criar fatura", icon: "receipt", soon: "Fatura tem de estar ligada a uma marcação concluída — em breve" },
  ];
  items.forEach((it) => {
    const el = h("button", { class: "novo-item", role: "menuitem", disabled: !!it.soon, title: it.soon || "",
      onclick: it.run ? () => { closeMenu(); it.run(); } : null },
      icon(it.icon), h("span", {}, it.label), it.soon ? h("span", { class: "novo-soon" }, "Em breve") : null);
    menu.append(el);
  });
  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("click", (e) => { if (!wrap.contains(e.target)) closeMenu(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });
}

document.addEventListener("DOMContentLoaded", () => {
  Drawer.init();
  Modal.init();
  initNovoMenu();
  $("#menu-btn").addEventListener("click", () => { $("#sidebar").classList.toggle("open"); $("#scrim").classList.toggle("open"); });
  $("#scrim").addEventListener("click", () => { $("#sidebar").classList.remove("open"); });
  const THEME_KEY = "db_theme";
  const prefersDark = () => window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  const themeBtn = $("#theme-btn");
  const themeBtnIcon = $("#theme-btn-icon");
  const applyTheme = (t) => {
    document.documentElement.dataset.theme = t;
    themeBtnIcon.setAttribute("href", t === "dark" ? "#i-sun" : "#i-moon");
    themeBtn.setAttribute("aria-label", t === "dark" ? "Ativar modo claro" : "Ativar modo escuro");
  };
  applyTheme(prefersDark() ? "dark" : "light");
  try { const saved = localStorage.getItem(THEME_KEY); if (saved) applyTheme(saved); } catch (e) {}
  requestAnimationFrame(() => document.body.classList.add("theme-ready"));
  themeBtn.addEventListener("click", () => {
    const cur = document.documentElement.dataset.theme || (prefersDark() ? "dark" : "light");
    const next = cur === "light" ? "dark" : "light";
    applyTheme(next);
    try { localStorage.setItem(THEME_KEY, next); } catch (e) {}
  });
  if (!location.hash) location.hash = "#/hoje";
  Router.render(parseHash());
});
